import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useCart } from '../context/CartContext'

const FALLBACK_PRODUCTS = [
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8501",
    name: "Aura Wireless Pro",
    description: "Premium sleek wireless noise-canceling headphones in matte emerald green. Experience high-fidelity audio engineering, custom tuned acoustic drivers, and industry-leading smart active noise cancellation. With up to 40 hours of battery life and ergonomic memory foam earcups, the Aura Wireless Pro ensures comfortable listening throughout your day.",
    price: 249.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBdMVluHZCODe5_mkvaNc7jVMkirAFkoyZQ8bcdeMSjEp4PzByaT29-s0DZ-Rf5e1fbE0eKBtBmHnapFPdSTmIB5VbXoSUZHPTNPExDwTp0ZiX8zjhbCAmopFuLqp3V_kyS6JWc7J9VcF1dF7NejnSw5zihuQf23xFgEHt_xmC85CMuhjcTs0N_TaEUfpXHXo3tR0hF2sLle9W8DqfIAa2pY8kpbAp2PhN6FOrhmLGhNpUAVKzABlnC_1RH3srCZRGWuwQleYf4WAY",
    category_name: "Electronics",
    stock_qty: 12,
    rating: 4.8,
    reviews: 124,
    specs: {
      "Battery Life": "Up to 40 hours",
      "Bluetooth": "Version 5.2",
      "Driver Size": "40mm Custom Dynamic",
      "Weight": "250g"
    }
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8502",
    name: "Organic Extra Virgin Oil",
    description: "Artisanal organic extra virgin olive oil cold pressed from premium hand-picked olives. Our olive oil features a delicate grassy aroma with a peppery finish, perfect for drizzling over fresh salads, dipping crusty artisan bread, or finishing grilled vegetables. 100% natural, single-estate sourced, and packed with antioxidants.",
    price: 18.50,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuAE92w9J68Nyp9lmYgsgt7CQfNqvewWKn12JpeSsGFfgRcaAdC7BqOlvtMWp8VrbEEPTFAkj7z69Fg9L9ESnBe7J161uK4acO0eQO1xDf0jV1tLcHTmrPc5n1lDe97N7owZ7mJ85Dkcazo7HkWCNY2P-RfE7vZLCdj7oLbqUBabl3xWeU4Guf7bv0CIqHPAfuNdaKOIhvOF7snW7GxjNh5k182o2WLTNdV511oevDHQrZklIb3J28XviZNeLFWmICS5bH2Gy1pX57M",
    category_name: "Grocery",
    stock_qty: 45,
    rating: 5.0,
    reviews: 89,
    specs: {
      "Volume": "500ml",
      "Source": "Peloponnese, Greece",
      "Acidity": "< 0.3%",
      "Processing": "Cold Pressed"
    }
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8503",
    name: "Linen Blend Shirt",
    description: "A stylish, minimalist cotton linen shirt in a soft sage green color, neatly folded. Tailored from a breathable organic cotton-linen blend, this shirt keeps you cool and elegant in warm weather. Features a clean, relaxed-fit silhouette, classical button-down front, and chest pocket. Pre-washed for maximum softness.",
    price: 45.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBqdMWOBZcokiDLMTczffgdTVe27nTHQ-XdfJyVCbR_SE7VrHzlUpyrhoGCDeJBlmKd3_orgpFEoHEgXJ-1bUr2V1k5BccD9iOtkWQJgHtKUWci0_2KMJJ9_t5rRYfrTxrUyDekHd_OqsujfJkvVGrIJPX04iWM24Eie9K787QhKDuvTpC41FyjRi-0zIGTBsmu0lDOsB5vDIPgA0isPDcav8OhHiTJCLm1ttgISZ5XlejPBxuwZ396L4N-2upjZccoBOCIfBFTbxY",
    category_name: "Fashion",
    stock_qty: 8,
    rating: 4.2,
    reviews: 42,
    specs: {
      "Material": "55% Linen, 45% Cotton",
      "Fit": "Relaxed / Classic",
      "Wash": "Machine Wash Cold",
      "Origin": "Ethically Made in Portugal"
    }
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8504",
    name: "Eco Glass Flask",
    description: "Modern, minimalist glass water bottle with a premium bamboo lid and soft-touch green silicone sleeve. Made from durable borosilicate glass, it is highly heat-resistant and preserves the pure flavor of your drinks. The protective sleeve prevents cracks and provides a comfortable, slip-free grip. 100% BPA-free and sustainable.",
    price: 32.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBCkNDvL46cxZQ86qDxs8fXO0VDcxEbso8rllX_njC-fzLrDQQdq-C3i7ovedevr2SzIbX0Nd2jOfXzxiRo8sm_1JRxkf0X3AJDK7ivuH0x-IIYyBl72epT7-7nDu-ZUP5Sj6hq0ko9qxGctZoVrUGC129FhMCHaliGhR-upzne6ewZ1QVwesvpWvxLC33Q6HpB0o11UVAexk-YeybLdQ3n4jRuEDdQNmPUZMSX-2_yXxCcFk0-674Pm2gmJrEEvVXQoaB9g4uBD7E",
    category_name: "Home Care",
    stock_qty: 24,
    rating: 4.9,
    reviews: 216,
    specs: {
      "Capacity": "750ml",
      "Material": "Borosilicate Glass, Bamboo, Silicone",
      "Temp Range": "-20°C to 120°C",
      "Leak Proof": "Yes (Silicone ring gasket)"
    }
  }
]

export const ProductDetail = ({ productId, navigate }) => {
  const { addToCart } = useCart()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [quantity, setQuantity] = useState(1)
  const [toastMessage, setToastMessage] = useState('')

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true)
        
        // 1. Fetch from Supabase
        const { data, error } = await supabase
          .from('products')
          .select('*, categories(name)')
          .eq('id', productId)
          .single()

        if (!error && data) {
          setProduct({
            ...data,
            category_name: data.categories?.name || 'General',
            specs: data.specs || {
              "Material": "High Quality",
              "Stock": `${data.stock_qty} items available`
            }
          })
        } else {
          // Fallback if not found in db or db empty
          const fallback = FALLBACK_PRODUCTS.find(p => p.id === productId)
          if (fallback) {
            setProduct(fallback)
          }
        }
      } catch (err) {
        console.error('Error fetching product details:', err)
      } finally {
        setLoading(false)
      }
    }

    if (productId) {
      fetchProduct()
    }
  }, [productId])

  const triggerToast = (msg) => {
    setToastMessage(msg)
    setTimeout(() => setToastMessage(''), 2000)
  }

  const handleAddToCart = () => {
    if (!product) return
    addToCart(product, quantity)
    triggerToast(`${quantity}x ${product.name} added to cart!`)
  }

  if (loading) {
    return (
      <div className="pt-24 pb-20 text-center">
        <span className="material-symbols-outlined text-[64px] text-primary animate-spin">sync</span>
        <p className="mt-md font-headline font-semibold text-on-surface">Loading product details...</p>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="pt-24 pb-20 text-center px-margin-mobile">
        <span className="material-symbols-outlined text-[64px] text-error">warning</span>
        <p className="mt-md font-headline font-semibold text-on-surface">Product not found</p>
        <button onClick={() => navigate('/products')} className="mt-md bg-primary text-on-primary px-lg py-sm rounded-full font-bold">
          Back to Catalog
        </button>
      </div>
    )
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto overflow-x-hidden text-left px-margin-mobile md:px-margin-desktop">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-20 right-4 bg-on-primary-container text-white px-md py-sm rounded-lg shadow-xl z-[60] animate-bounce">
          {toastMessage}
        </div>
      )}

      {/* Breadcrumb */}
      <div className="py-sm flex items-center gap-xs text-xs font-semibold text-on-surface-variant">
        <button onClick={() => navigate('/')} className="hover:text-primary transition-colors">Home</button>
        <span className="material-symbols-outlined text-xs">chevron_right</span>
        <button onClick={() => navigate('/products')} className="hover:text-primary transition-colors">Shop</button>
        <span className="material-symbols-outlined text-xs">chevron_right</span>
        <span className="text-on-surface truncate">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-xl pt-sm">
        {/* Left: Product Image */}
        <div className="md:col-span-6">
          <div className="aspect-square bg-surface-container-low rounded-2xl overflow-hidden border border-outline-variant/30 relative">
            {product.stock_qty <= 0 && (
              <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-10 flex items-center justify-center">
                <span className="bg-error text-on-error text-sm font-bold px-4 py-1.5 rounded-full uppercase">Out of Stock</span>
              </div>
            )}
            <div 
              className="w-full h-full bg-cover bg-center" 
              style={{ backgroundImage: `url('${product.image_url}')` }}
            ></div>
          </div>
        </div>

        {/* Right: Info Area */}
        <div className="md:col-span-6 flex flex-col justify-between space-y-md">
          <div>
            <span className="text-primary font-bold text-label-md uppercase tracking-wider">{product.category_name}</span>
            <h2 className="font-headline font-bold text-headline-lg-mobile md:text-headline-lg text-on-surface mt-xs">{product.name}</h2>
            
            {/* Reviews */}
            <div className="flex items-center gap-xs my-sm">
              <div className="flex text-[#FFB800]">
                {[...Array(5)].map((_, i) => (
                  <span 
                    key={i} 
                    className="material-symbols-outlined text-base" 
                    data-icon="star"
                    style={{ fontVariationSettings: i < Math.floor(product.rating || 5) ? "'FILL' 1" : "'FILL' 0" }}
                  >
                    star
                  </span>
                ))}
              </div>
              <span className="text-on-surface-variant font-label-sm">({product.reviews || 45} customer reviews)</span>
            </div>

            {/* Price */}
            <div className="my-md">
              <span className="text-primary font-bold text-[36px] font-headline">${parseFloat(product.price).toFixed(2)}</span>
            </div>

            {/* Description */}
            <p className="text-on-surface-variant font-body-md leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Action Row */}
          {product.stock_qty > 0 ? (
            <div className="space-y-sm bg-surface-container-low p-md rounded-2xl border border-outline-variant/20">
              <div className="flex items-center gap-md">
                <span className="font-label-md font-bold text-on-surface">Quantity:</span>
                <div className="flex items-center bg-surface-container-lowest border border-outline-variant/30 rounded-full px-sm py-1">
                  <button 
                    onClick={() => setQuantity(q => Math.max(1, q - 1))}
                    className="w-8 h-8 rounded-full flex items-center justify-center font-bold hover:bg-secondary-container/50 text-on-surface-variant"
                  >
                    -
                  </button>
                  <span className="px-md font-headline font-bold text-on-surface text-center w-12">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(q => Math.min(product.stock_qty, q + 1))}
                    className="w-8 h-8 rounded-full flex items-center justify-center font-bold hover:bg-secondary-container/50 text-on-surface-variant"
                  >
                    +
                  </button>
                </div>
                <span className="text-xs text-on-surface-variant font-semibold">({product.stock_qty} in stock)</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-sm pt-xs">
                <button 
                  onClick={handleAddToCart}
                  className="flex-1 bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container px-lg py-sm rounded-full font-bold active:scale-95 transition-all flex items-center justify-center gap-xs"
                >
                  <span className="material-symbols-outlined">add_shopping_cart</span> Add to Cart
                </button>
                <button 
                  onClick={() => { handleAddToCart(); navigate('/cart'); }}
                  className="flex-1 bg-primary-container text-on-primary-container px-lg py-sm rounded-full font-bold hover:opacity-90 active:scale-95 transition-all"
                >
                  Buy It Now
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-error-container/20 border border-error/20 p-md rounded-2xl text-center">
              <p className="text-error font-bold font-headline">This item is currently out of stock.</p>
              <button 
                onClick={() => navigate('/products')} 
                className="mt-sm bg-surface-container-lowest border border-outline-variant hover:bg-secondary-container text-on-surface font-label-md px-md py-2 rounded-full"
              >
                Explore Other Products
              </button>
            </div>
          )}

          {/* Specifications Grid */}
          <div className="border-t border-outline-variant/20 pt-md mt-md">
            <h3 className="font-headline font-semibold text-headline-md text-on-surface mb-sm">Specifications</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-sm">
              {Object.entries(product.specs).map(([key, val]) => (
                <div key={key} className="flex justify-between border-b border-outline-variant/10 pb-xs">
                  <span className="font-label-md text-on-surface-variant">{key}</span>
                  <span className="font-label-md font-bold text-on-surface">{val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
