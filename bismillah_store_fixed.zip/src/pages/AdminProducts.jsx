import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'

export const AdminProducts = ({ navigate }) => {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)

  // Form states for creating/editing
  const [editingProduct, setEditingProduct] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('')
  const [imageUrl, setImageUrl] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [stockQty, setStockQty] = useState(0)
  const [isActive, setIsActive] = useState(true)

  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState('')

  const fetchAll = async () => {
    try {
      setLoading(true)
      // Get categories
      const { data: catData } = await supabase.from('categories').select('*').order('name')
      if (catData) setCategories(catData)

      // Get products
      const { data: prodData } = await supabase
        .from('products')
        .select('*, categories(name)')
        .order('created_at', { ascending: false })

      if (prodData) setProducts(prodData)
    } catch (err) {
      console.error('Error fetching admin products:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAll()
  }, [])

  const handleEditClick = (prod) => {
    setEditingProduct(prod)
    setName(prod.name)
    setDescription(prod.description || '')
    setPrice(prod.price)
    setImageUrl(prod.image_url || '')
    setCategoryId(prod.category_id || '')
    setStockQty(prod.stock_qty)
    setIsActive(prod.is_active)
    setShowForm(true)
    setErrorMsg('')
    setSuccessMsg('')
  }

  const handleCreateClick = () => {
    setEditingProduct(null)
    setName('')
    setDescription('')
    setPrice('')
    setImageUrl('')
    setCategoryId(categories[0]?.id || '')
    setStockQty(10)
    setIsActive(true)
    setShowForm(true)
    setErrorMsg('')
    setSuccessMsg('')
  }

  const handleSave = async (e) => {
    e.preventDefault()
    setErrorMsg('')
    setSuccessMsg('')

    if (!name.trim() || !price || stockQty < 0) {
      setErrorMsg('Please enter valid product details.')
      return
    }

    const payload = {
      name: name.trim(),
      description: description.trim(),
      price: parseFloat(price),
      image_url: imageUrl.trim() || 'https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=300&auto=format&fit=crop',
      category_id: categoryId || null,
      stock_qty: parseInt(stockQty),
      is_active: isActive
    }

    try {
      if (editingProduct) {
        // Update
        const { error } = await supabase
          .from('products')
          .update(payload)
          .eq('id', editingProduct.id)

        if (error) throw error
        setSuccessMsg('Product updated successfully!')
      } else {
        // Insert
        const { error } = await supabase
          .from('products')
          .insert(payload)

        if (error) throw error
        setSuccessMsg('Product added successfully!')
      }

      setShowForm(false)
      setEditingProduct(null)
      fetchAll()
    } catch (err) {
      console.error('Error saving product:', err)
      setErrorMsg(err.message || 'Error occurred while saving product details.')
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto text-left px-margin-mobile md:px-margin-desktop">
      <div className="pt-md pb-lg flex justify-between items-center">
        <div>
          <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Product Catalog Management</h2>
          <p className="text-on-surface-variant font-label-md">Add, update, or toggle visibility of inventory products</p>
        </div>
        <button 
          onClick={handleCreateClick}
          className="bg-primary text-on-primary font-bold font-label-md px-md py-2 rounded-full hover:bg-primary-container hover:text-on-primary-container active:scale-95 transition-all flex items-center gap-xs"
        >
          <span className="material-symbols-outlined text-sm">add</span> Add New Product
        </button>
      </div>

      {errorMsg && (
        <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
          {errorMsg}
        </div>
      )}

      {successMsg && (
        <div className="bg-primary-container/20 text-on-primary-container p-sm rounded-lg text-xs font-semibold mb-md border border-primary/20">
          {successMsg}
        </div>
      )}

      {/* CRUD Edit/Create Form Container */}
      {showForm && (
        <div className="bg-surface-container-low p-md rounded-2xl border border-outline-variant/30 mb-lg animate-fade-in-up">
          <h3 className="font-headline font-semibold text-headline-md text-on-surface mb-md">
            {editingProduct ? `Edit: ${editingProduct.name}` : 'Create New Product'}
          </h3>
          <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-md">
            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Product Name</label>
              <input 
                type="text" 
                required 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/35 rounded p-2 focus:ring-2 focus:ring-primary-container text-on-surface"
              />
            </div>

            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Category</label>
              <select 
                value={categoryId} 
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/35 rounded p-2 focus:ring-2 focus:ring-primary-container text-on-surface"
              >
                <option value="">No Category</option>
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Product Description</label>
              <textarea 
                rows="2" 
                value={description} 
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/35 rounded p-2 focus:ring-2 focus:ring-primary-container text-on-surface"
              />
            </div>

            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Price ($)</label>
              <input 
                type="number" 
                step="0.01" 
                required 
                value={price} 
                onChange={(e) => setPrice(e.target.value)} 
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/35 rounded p-2 focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
              />
            </div>

            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Stock Quantity</label>
              <input 
                type="number" 
                required 
                value={stockQty} 
                onChange={(e) => setStockQty(e.target.value)} 
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/35 rounded p-2 focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Image URL</label>
              <input 
                type="url" 
                value={imageUrl} 
                onChange={(e) => setImageUrl(e.target.value)} 
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/35 rounded p-2 focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
                placeholder="https://..."
              />
            </div>

            <div className="flex items-center gap-xs">
              <input 
                type="checkbox" 
                id="isActive"
                checked={isActive} 
                onChange={(e) => setIsActive(e.target.checked)} 
                className="accent-primary w-4 h-4"
              />
              <label htmlFor="isActive" className="text-sm font-bold text-on-surface cursor-pointer select-none">Active / Visible on Storefront</label>
            </div>

            <div className="md:col-span-2 flex justify-end gap-sm pt-sm border-t border-outline-variant/10">
              <button 
                type="button" 
                onClick={() => { setShowForm(false); setEditingProduct(null); }}
                className="bg-surface-container-lowest border border-outline-variant text-on-surface px-md py-sm rounded-full font-bold active:scale-95"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="bg-primary text-on-primary px-lg py-sm rounded-full font-bold active:scale-95 hover:bg-primary-container hover:text-on-primary-container"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Denser Admin Data Table */}
      {loading ? (
        <div className="text-center py-10">
          <span className="material-symbols-outlined text-[48px] text-primary animate-spin">sync</span>
        </div>
      ) : (
        <div className="bg-surface-container-lowest rounded-2xl border border-outline-variant/20 overflow-x-auto shadow-sm">
          <table className="w-full min-w-[720px] text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-low border-b border-outline-variant/20 text-xs font-bold text-on-surface-variant">
                <th className="py-sm px-md">Product Image</th>
                <th className="py-sm px-md">Name</th>
                <th className="py-sm px-md">Category</th>
                <th className="py-sm px-md">Price</th>
                <th className="py-sm px-md">Stock</th>
                <th className="py-sm px-md">Status</th>
                <th className="py-sm px-md text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-outline-variant/10 text-sm">
              {products.map((prod) => (
                <tr key={prod.id} className="hover:bg-secondary-container/10 transition-colors">
                  <td className="py-sm px-md">
                    <div 
                      className="w-12 h-12 bg-cover bg-center rounded-lg border border-outline-variant/20"
                      style={{ backgroundImage: `url('${prod.image_url}')` }}
                    ></div>
                  </td>
                  <td className="py-sm px-md font-semibold text-on-surface">{prod.name}</td>
                  <td className="py-sm px-md text-on-surface-variant">{prod.categories?.name || 'Uncategorized'}</td>
                  <td className="py-sm px-md font-mono text-primary font-semibold">${parseFloat(prod.price).toFixed(2)}</td>
                  <td className={`py-sm px-md font-mono font-semibold ${prod.stock_qty <= 3 ? 'text-error' : 'text-on-surface'}`}>
                    {prod.stock_qty}
                  </td>
                  <td className="py-sm px-md">
                    <span className={`px-sm py-0.5 rounded text-[10px] font-bold ${prod.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                      {prod.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="py-sm px-md text-right">
                    <button 
                      onClick={() => handleEditClick(prod)}
                      className="text-xs bg-secondary-container text-on-secondary-container hover:bg-primary-container hover:text-on-primary-container px-sm py-1 rounded font-semibold transition-all"
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  )
}
