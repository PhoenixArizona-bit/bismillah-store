import React, { useEffect, useState } from 'react'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../supabaseClient'
import confetti from 'canvas-confetti'

export const Checkout = ({ navigate }) => {
  const { user, profile } = useAuth()
  const { cart, cartTotal, clearCart } = useCart()

  // Form inputs
  const [fullName, setFullName] = useState(profile?.full_name || '')
  const [phone, setPhone] = useState(profile?.phone || '')
  const [address, setAddress] = useState(profile?.address || '')
  const [selectedMethod, setSelectedMethod] = useState('')
  const [transactionId, setTransactionId] = useState('')

  // Settings
  const [paymentMethodsActive, setPaymentMethodsActive] = useState({ jazzcash: true, easypaisa: true })
  const [paymentDetails, setPaymentDetails] = useState({
    jazzcash: { account_number: "0300-1234567", account_name: "Bismillah Store" },
    easypaisa: { account_number: "0315-9876543", account_name: "Bismillah Store" }
  })

  // Status
  const [loading, setLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [success, setSuccess] = useState(false)
  const [newOrderId, setNewOrderId] = useState('')

  useEffect(() => {
    // Redirect if cart is empty and checkout hasn't succeeded yet
    if (cart.length === 0 && !success) {
      navigate('/cart')
    }

    // Fetch active payment methods from settings
    const fetchSettings = async () => {
      try {
        const { data, error } = await supabase
          .from('store_settings')
          .select('payment_methods_active, payment_account_details')
          .eq('id', 1)
          .single()

        if (!error && data) {
          if (data.payment_methods_active) {
            setPaymentMethodsActive(data.payment_methods_active)
          }
          // Note: payment_account_details might be null for normal customers due to RLS.
          // If available (admin/dev), we use it. Otherwise, we rely on our default fallbacks.
          if (data.payment_account_details) {
            setPaymentDetails(data.payment_account_details)
          }
        }
      } catch (err) {
        console.error('Settings fetch error:', err)
      }
    }

    fetchSettings()
  }, [cart, success])

  const handlePlaceOrder = async (e) => {
    e.preventDefault()
    if (!selectedMethod) {
      setErrorMessage('Please select a payment method.')
      return
    }
    if (!transactionId.trim()) {
      setErrorMessage('Please enter the manual transaction ID.')
      return
    }

    setLoading(true)
    setErrorMessage('')

    try {
      // 1. Insert Profile details if changed/missing
      if (fullName !== profile?.full_name || phone !== profile?.phone || address !== profile?.address) {
        await supabase
          .from('profiles')
          .update({
            full_name: fullName,
            phone: phone,
            address: address
          })
          .eq('id', user.id)
      }

      // 2. Insert order
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          status: 'pending',
          total_amount: cartTotal,
          payment_method: selectedMethod,
          transaction_id: transactionId.trim()
        })
        .select()
        .single()

      if (orderError) throw orderError

      // 3. Insert order items
      const orderItemsToInsert = cart.map(item => ({
        order_id: order.id,
        product_id: item.id,
        quantity: item.quantity,
        unit_price: parseFloat(item.price)
      }))

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItemsToInsert)

      if (itemsError) throw itemsError

      // Success sequence
      confetti({
        particleCount: 150,
        spread: 80,
        origin: { y: 0.6 }
      })

      setNewOrderId(order.id)
      setSuccess(true)
      clearCart()
    } catch (err) {
      console.error('Checkout error:', err)
      setErrorMessage(err.message || 'Error processing your order. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <main className="pt-16 pb-24 md:pb-12 max-w-[640px] mx-auto text-center px-margin-mobile">
        <div className="py-20 bg-surface-container-low rounded-2xl border border-outline-variant/20 mt-lg space-y-md">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto text-primary animate-pulse">
            <span className="material-symbols-outlined text-[48px]">check_circle</span>
          </div>
          <h2 className="font-headline font-bold text-headline-lg text-on-surface">Order Placed Successfully!</h2>
          <p className="text-on-surface-variant font-label-md max-w-md mx-auto">
            Your order has been logged with **Status: Pending**. An administrator will verify the transaction ID **({transactionId})** shortly.
          </p>
          <div className="bg-surface-container-lowest p-md rounded-xl max-w-md mx-auto border border-outline-variant/10 text-left space-y-xs">
            <div className="flex justify-between text-xs text-on-surface-variant">
              <span>Order Reference:</span>
              <span className="font-bold text-on-surface font-mono">{newOrderId}</span>
            </div>
            <div className="flex justify-between text-xs text-on-surface-variant">
              <span>Total Amount:</span>
              <span className="font-bold text-primary">${cartTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-xs text-on-surface-variant">
              <span>Payment Type:</span>
              <span className="font-bold text-on-surface capitalize">{selectedMethod}</span>
            </div>
          </div>
          <div className="pt-md">
            <button 
              onClick={() => navigate('/orders')} 
              className="bg-primary text-on-primary px-lg py-sm rounded-full font-bold active:scale-95 transition-all"
            >
              View Order History
            </button>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto text-left px-margin-mobile md:px-margin-desktop">
      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Order Checkout</h2>
        <p className="text-on-surface-variant font-label-md">Complete manual payment and finalize your details</p>
      </div>

      {errorMessage && (
        <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
          {errorMessage}
        </div>
      )}

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
        {/* Billing/Shipping Address Details */}
        <div className="lg:col-span-7 bg-surface-container-low p-md rounded-2xl border border-outline-variant/20 space-y-md">
          <h3 className="font-headline font-semibold text-headline-md text-on-surface">Delivery Address</h3>
          
          <div className="space-y-sm">
            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Recipient Name</label>
              <input 
                type="text" 
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                placeholder="Recipient name"
              />
            </div>
            
            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Mobile Number</label>
              <input 
                type="tel" 
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                placeholder="03001234567"
              />
            </div>

            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Complete Street Address</label>
              <textarea 
                rows="3"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                placeholder="House No, Street, Area, City..."
              ></textarea>
            </div>
          </div>
        </div>

        {/* Payments Column */}
        <div className="lg:col-span-5 space-y-gutter">
          {/* Payment Details Container */}
          <div className="bg-surface-container-low p-md rounded-2xl border border-outline-variant/20 space-y-md">
            <h3 className="font-headline font-semibold text-headline-md text-on-surface">Select Manual Payment</h3>
            <p className="text-xs text-on-surface-variant font-medium">
              Send the exact total amount externally to one of the accounts below, then copy/paste your transaction ID.
            </p>

            <div className="space-y-sm">
              {paymentMethodsActive.jazzcash && (
                <label className="border border-outline-variant/35 rounded-xl p-sm flex items-center justify-between cursor-pointer hover:bg-secondary-container/30 transition-colors">
                  <div className="flex items-center gap-xs">
                    <input 
                      type="radio" 
                      name="payment_method" 
                      value="jazzcash"
                      checked={selectedMethod === 'jazzcash'}
                      onChange={() => setSelectedMethod('jazzcash')}
                      className="accent-primary" 
                    />
                    <div className="ml-xs">
                      <span className="font-bold text-on-surface block text-sm">JazzCash Mobile Wallet</span>
                      <span className="text-xs text-on-surface-variant">Acc Number: <strong className="font-mono text-on-surface">{paymentDetails.jazzcash.account_number}</strong></span>
                      <span className="text-xs text-on-surface-variant block">Acc Title: {paymentDetails.jazzcash.account_name}</span>
                    </div>
                  </div>
                  <span className="material-symbols-outlined text-primary text-xl">wallet</span>
                </label>
              )}

              {paymentMethodsActive.easypaisa && (
                <label className="border border-outline-variant/35 rounded-xl p-sm flex items-center justify-between cursor-pointer hover:bg-secondary-container/30 transition-colors">
                  <div className="flex items-center gap-xs">
                    <input 
                      type="radio" 
                      name="payment_method" 
                      value="easypaisa"
                      checked={selectedMethod === 'easypaisa'}
                      onChange={() => setSelectedMethod('easypaisa')}
                      className="accent-primary" 
                    />
                    <div className="ml-xs">
                      <span className="font-bold text-on-surface block text-sm">Easypaisa Mobile Wallet</span>
                      <span className="text-xs text-on-surface-variant">Acc Number: <strong className="font-mono text-on-surface">{paymentDetails.easypaisa.account_number}</strong></span>
                      <span className="text-xs text-on-surface-variant block">Acc Title: {paymentDetails.easypaisa.account_name}</span>
                    </div>
                  </div>
                  <span className="material-symbols-outlined text-primary text-xl">payments</span>
                </label>
              )}
            </div>

            {selectedMethod && (
              <div className="bg-surface-container-lowest p-sm rounded-xl border border-outline-variant/20 animate-fade-in-up mt-sm">
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Transaction ID (TID)</label>
                <input 
                  type="text" 
                  required
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  className="w-full bg-surface-container-low border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
                  placeholder="Enter 11 or 12 digit Transaction ID"
                />
              </div>
            )}
          </div>

          {/* Checkout Submit Card */}
          <div className="bg-surface-container-low p-md rounded-2xl border border-outline-variant/20 space-y-md">
            <div className="flex justify-between text-on-surface font-headline font-bold text-headline-md border-b border-outline-variant/10 pb-sm">
              <span>Payable Total:</span>
              <span className="text-primary">${cartTotal.toFixed(2)}</span>
            </div>
            
            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container py-sm rounded-full font-bold active:scale-95 transition-all flex items-center justify-center gap-xs disabled:bg-secondary-container disabled:text-on-secondary-container"
            >
              {loading ? (
                <span className="material-symbols-outlined text-sm animate-spin">sync</span>
              ) : (
                'Place Order (Manual Confirmation)'
              )}
            </button>
          </div>
        </div>
      </form>
    </main>
  )
}
