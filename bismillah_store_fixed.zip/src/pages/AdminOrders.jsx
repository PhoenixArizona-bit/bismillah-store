import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'

export const AdminOrders = ({ navigate }) => {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [filterStatus, setFilterStatus] = useState('all')

  const fetchOrders = async () => {
    try {
      setLoading(true)
      let query = supabase
        .from('orders')
        .select(`
          *,
          profiles (
            full_name,
            phone,
            address
          ),
          order_items (
            *,
            products (
              name
            )
          )
        `)
        .order('created_at', { ascending: false })

      if (filterStatus !== 'all') {
        query = query.eq('status', filterStatus)
      }

      const { data, error } = await query
      if (!error && data) {
        setOrders(data)
      }
    } catch (err) {
      console.error('Error fetching admin orders:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchOrders()
  }, [filterStatus])

  const handleUpdateStatus = async (orderId, newStatus) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId)

      if (error) throw error
      alert(`Order status updated to ${newStatus}!`)
      fetchOrders()
    } catch (err) {
      console.error('Error updating order status:', err)
      alert(err.message || 'Error occurred while updating status.')
    }
  }

  const getStatusStyle = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-amber-100 text-amber-800'
      case 'confirmed':
        return 'bg-blue-100 text-blue-800'
      case 'fulfilled':
        return 'bg-green-100 text-green-800'
      case 'cancelled':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto text-left px-margin-mobile md:px-margin-desktop">
      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Order Management</h2>
        <p className="text-on-surface-variant font-label-md">Audit manual payments and adjust order delivery stages</p>
      </div>

      {/* Filter tab buttons */}
      <div className="flex gap-xs flex-wrap mb-md bg-surface-container-low p-1.5 rounded-xl border border-outline-variant/20 w-fit">
        {['all', 'pending', 'confirmed', 'fulfilled', 'cancelled'].map(status => (
          <button
            key={status}
            onClick={() => setFilterStatus(status)}
            className={`px-sm py-1.5 rounded-lg text-xs font-bold capitalize transition-all ${filterStatus === status ? 'bg-primary text-on-primary shadow-sm' : 'text-on-surface-variant hover:text-primary'}`}
          >
            {status}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-10">
          <span className="material-symbols-outlined text-[48px] text-primary animate-spin">sync</span>
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-20 bg-surface-container-lowest rounded-2xl border border-outline-variant/20">
          <span className="material-symbols-outlined text-[80px] text-on-surface-variant mb-md">receipt_long</span>
          <p className="font-headline font-semibold text-headline-md text-on-surface">No orders found</p>
          <p className="text-on-surface-variant font-label-md mt-xs">There are no orders matching status: "{filterStatus}"</p>
        </div>
      ) : (
        <div className="space-y-md">
          {orders.map(order => (
            <div key={order.id} className="bg-surface-container-lowest p-md rounded-2xl border border-outline-variant/20 space-y-sm">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-xs pb-xs border-b border-outline-variant/10">
                <div>
                  <span className="text-[10px] text-on-surface-variant font-mono block">Order ID: {order.id}</span>
                  <span className="text-xs text-on-surface-variant font-semibold">
                    Placed: {new Date(order.created_at).toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center gap-xs">
                  <span className={`px-sm py-1 rounded-full text-xs font-bold capitalize ${getStatusStyle(order.status)}`}>
                    {order.status}
                  </span>
                </div>
              </div>

              {/* Customer and payment columns */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-md py-xs">
                {/* Delivery details */}
                <div>
                  <span className="text-xs font-bold text-on-surface block mb-xs">Recipient Details</span>
                  <p className="text-sm font-semibold text-on-surface">{order.profiles?.full_name || 'Anonymous'}</p>
                  <p className="text-xs text-on-surface-variant">{order.profiles?.phone || 'No phone'}</p>
                  <p className="text-xs text-on-surface-variant truncate max-w-xs" title={order.profiles?.address}>{order.profiles?.address || 'No address provided'}</p>
                </div>

                {/* Manual payment check details */}
                <div>
                  <span className="text-xs font-bold text-on-surface block mb-xs">Manual Payment Check</span>
                  <p className="text-sm font-semibold text-on-surface block capitalize">{order.payment_method} Wallet</p>
                  <p className="text-xs text-on-surface-variant">TID: <strong className="font-mono text-on-surface">{order.transaction_id}</strong></p>
                  <p className="text-xs text-primary font-bold">Total Paid: ${parseFloat(order.total_amount).toFixed(2)}</p>
                </div>

                {/* Items listing */}
                <div>
                  <span className="text-xs font-bold text-on-surface block mb-xs">Items ({order.order_items?.length || 0})</span>
                  <ul className="text-xs space-y-0.5 text-on-surface-variant max-h-24 overflow-y-auto pr-xs">
                    {order.order_items?.map((item, idx) => (
                      <li key={idx} className="truncate">
                        • {item.products?.name} (x{item.quantity})
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Status Actions */}
              <div className="bg-surface-container-low p-sm rounded-xl flex flex-wrap justify-between items-center gap-xs pt-xs">
                <span className="text-[10px] text-on-surface-variant font-bold">Actions:</span>
                <div className="flex gap-xs">
                  {order.status === 'pending' && (
                    <button
                      onClick={() => handleUpdateStatus(order.id, 'confirmed')}
                      className="text-xs bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container px-sm py-1.5 rounded font-bold transition-all"
                    >
                      Confirm Payment
                    </button>
                  )}
                  {order.status === 'confirmed' && (
                    <button
                      onClick={() => handleUpdateStatus(order.id, 'fulfilled')}
                      className="text-xs bg-green-600 text-on-green px-sm py-1.5 rounded font-bold text-white transition-all hover:bg-green-700"
                    >
                      Mark Shipped / Fulfilled
                    </button>
                  )}
                  {order.status !== 'cancelled' && order.status !== 'fulfilled' && (
                    <button
                      onClick={() => handleUpdateStatus(order.id, 'cancelled')}
                      className="text-xs bg-red-50 text-red-600 hover:bg-red-100 px-sm py-1.5 rounded font-bold transition-all"
                    >
                      Cancel Order
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  )
}
