import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useAuth } from '../context/AuthContext'

export const Orders = ({ navigate }) => {
  const { user } = useAuth()
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return
      try {
        setLoading(true)
        const { data, error } = await supabase
          .from('orders')
          .select(`
            *,
            order_items (
              *,
              products (
                name,
                image_url
              )
            )
          `)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })

        if (!error && data) {
          setOrders(data)
        }
      } catch (err) {
        console.error('Error fetching customer orders:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchOrders()
  }, [user])

  const getStatusStyle = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-amber-100 text-amber-800'
      case 'confirmed':
        return 'bg-blue-100 text-blue-800'
      case 'fulfilled':
        return 'bg-green-100 text-green-800'
      case 'cancelled':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="pt-24 pb-20 text-center">
        <span className="material-symbols-outlined text-[64px] text-primary animate-spin">sync</span>
        <p className="mt-md font-headline font-semibold text-on-surface">Loading your order history...</p>
      </div>
    )
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[960px] mx-auto text-left px-margin-mobile">
      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">My Orders</h2>
        <p className="text-on-surface-variant font-label-md">Track the status of your purchases and transactions</p>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-20 bg-surface-container-low rounded-2xl border border-outline-variant/20">
          <span className="material-symbols-outlined text-[80px] text-on-surface-variant mb-md">receipt_long</span>
          <p className="font-headline font-semibold text-headline-md text-on-surface">No orders placed yet</p>
          <p className="text-on-surface-variant font-label-md mt-xs">Any purchases you make will appear here.</p>
          <button 
            onClick={() => navigate('/products')} 
            className="mt-lg bg-primary text-on-primary px-lg py-sm rounded-full font-bold"
          >
            Go Shop
          </button>
        </div>
      ) : (
        <div className="space-y-md">
          {orders.map((order) => (
            <div 
              key={order.id} 
              className="bg-surface-container-low p-md rounded-2xl border border-outline-variant/20 space-y-sm"
            >
              {/* Header details */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-xs pb-xs border-b border-outline-variant/10">
                <div>
                  <span className="text-[10px] text-on-surface-variant font-mono block">Order ID: {order.id}</span>
                  <span className="text-xs text-on-surface-variant font-semibold">
                    Placed on: {new Date(order.created_at).toLocaleDateString()} at {new Date(order.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex items-center gap-xs">
                  <span className={`px-sm py-1 rounded-full text-xs font-bold capitalize ${getStatusStyle(order.status)}`}>
                    {order.status}
                  </span>
                </div>
              </div>

              {/* Items details */}
              <div className="divide-y divide-outline-variant/10">
                {order.order_items?.map((item) => (
                  <div key={item.id} className="py-sm flex items-center justify-between gap-sm">
                    <div className="flex items-center gap-sm">
                      <div 
                        className="w-12 h-12 bg-cover bg-center rounded-lg border border-outline-variant/30 flex-shrink-0"
                        style={{ backgroundImage: `url('${item.products?.image_url}')` }}
                      ></div>
                      <div>
                        <span className="font-bold text-sm text-on-surface block">{item.products?.name}</span>
                        <span className="text-xs text-on-surface-variant">Qty: {item.quantity} x ${parseFloat(item.unit_price).toFixed(2)}</span>
                      </div>
                    </div>
                    <span className="font-bold text-sm text-on-surface">${(item.quantity * parseFloat(item.unit_price)).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              {/* Footer details */}
              <div className="bg-surface-container-lowest p-sm rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-xs text-xs">
                <div>
                  <span className="text-on-surface-variant block">Payment: <strong className="capitalize text-on-surface">{order.payment_method}</strong></span>
                  <span className="text-on-surface-variant font-mono block">TID: {order.transaction_id}</span>
                </div>
                <div className="text-right">
                  <span className="text-on-surface-variant block">Total Paid:</span>
                  <span className="font-headline font-bold text-primary text-headline-md">${parseFloat(order.total_amount).toFixed(2)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  )
}
