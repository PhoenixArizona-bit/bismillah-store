import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export const Auth = ({ navigate }) => {
  const { signIn, signUp, signInWithGoogle, user } = useAuth()
  const [isSignUp, setIsSignUp] = useState(false)
  
  // Form fields
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  
  // Status states
  const [loading, setLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')

  // Redirect if already logged in
  if (user) {
    setTimeout(() => navigate('/'), 500)
    return (
      <div className="pt-24 pb-20 text-center">
        <span className="material-symbols-outlined text-[64px] text-primary">done</span>
        <p className="mt-md font-headline font-semibold text-on-surface">Authenticated. Redirecting you home...</p>
      </div>
    )
  }

  const handleGoogleSignIn = async () => {
    setErrorMessage('')
    try {
      await signInWithGoogle()
      // Supabase redirects the browser to Google, then back to the app —
      // no further action needed here.
    } catch (err) {
      console.error('Google sign-in error:', err)
      setErrorMessage(err.message || 'Could not start Google sign-in.')
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setErrorMessage('')
    setSuccessMessage('')

    try {
      if (isSignUp) {
        await signUp(email, password, {
          full_name: fullName,
          phone: phone,
          address: address
        })
        setSuccessMessage('Registration successful! Please check your email for verification link, or try signing in if auto-approved.')
        setIsSignUp(false)
      } else {
        await signIn(email, password)
        setSuccessMessage('Logged in successfully! Redirecting...')
        setTimeout(() => navigate('/'), 1000)
      }
    } catch (err) {
      console.error('Auth action error:', err)
      setErrorMessage(err.message || 'An error occurred during authentication.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[480px] mx-auto text-left px-margin-mobile">
      <div className="bg-surface-container-low p-xl rounded-2xl border border-outline-variant/30 mt-lg shadow-sm">
        <div className="text-center mb-lg">
          <span className="material-symbols-outlined text-[48px] text-primary" data-icon="storefront">storefront</span>
          <h2 className="font-headline font-bold text-headline-lg text-on-surface mt-xs">
            {isSignUp ? 'Create an Account' : 'Welcome Back'}
          </h2>
          <p className="text-on-surface-variant font-label-md mt-xs">
            {isSignUp ? 'Register to start shopping in Bismillah Store' : 'Sign in to access your orders and account'}
          </p>
        </div>

        {errorMessage && (
          <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
            {errorMessage}
          </div>
        )}

        {successMessage && (
          <div className="bg-primary-container/20 text-on-primary-container p-sm rounded-lg text-xs font-semibold mb-md border border-primary/20">
            {successMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-md">
          {isSignUp && (
            <>
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Full Name</label>
                <input 
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Mobile Number</label>
                <input 
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                  placeholder="03001234567"
                />
              </div>
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Delivery Address</label>
                <input 
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                  placeholder="House #, Street, Area, City"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Email Address</label>
            <input 
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
              placeholder="name@example.com"
            />
          </div>

          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Password</label>
            <input 
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container py-sm rounded-full font-bold active:scale-95 transition-all flex items-center justify-center gap-xs disabled:bg-secondary-container disabled:text-on-secondary-container"
          >
            {loading ? (
              <span className="material-symbols-outlined text-sm animate-spin">sync</span>
            ) : (
              isSignUp ? 'Register Account' : 'Sign In'
            )}
          </button>
        </form>

        <div className="flex items-center gap-sm my-lg">
          <div className="flex-1 h-px bg-outline-variant/30" />
          <span className="text-on-surface-variant text-xs font-semibold">OR</span>
          <div className="flex-1 h-px bg-outline-variant/30" />
        </div>

        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full flex items-center justify-center gap-sm bg-surface border border-outline-variant/40 py-sm rounded-full font-bold text-on-surface hover:bg-surface-container-lowest active:scale-95 transition-all disabled:opacity-50"
        >
          <svg width="18" height="18" viewBox="0 0 48 48">
            <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.9 32.9 29.4 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.1 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z"/>
            <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 15.9 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.1 29.5 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
            <path fill="#4CAF50" d="M24 44c5.3 0 10.1-2 13.8-5.3l-6.4-5.4C29.3 35 26.8 36 24 36c-5.4 0-9.9-3.1-11.3-7.9l-6.6 5.1C9.6 39.6 16.2 44 24 44z"/>
            <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.3 5.7l6.4 5.4C39.4 37.4 44 31.4 44 24c0-1.3-.1-2.7-.4-3.5z"/>
          </svg>
          Continue with Google
        </button>

        <div className="mt-lg pt-md border-t border-outline-variant/20 text-center">
          <button 
            onClick={() => { setIsSignUp(!isSignUp); setErrorMessage(''); setSuccessMessage(''); }}
            className="text-primary font-bold font-label-md hover:underline"
          >
            {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
          </button>
        </div>
      </div>
    </main>
  )
}
