import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'

export const Navbar = ({ currentPath, navigate }) => {
  const { user, profile, signOut } = useAuth()
  const { cartCount } = useCart()
  const [logoTaps, setLogoTaps] = useState([])

  const handleLogoClick = () => {
    const now = Date.now()
    const updatedTaps = [...logoTaps, now].filter(t => now - t < 3000)
    
    if (updatedTaps.length >= 7) {
      // 7 taps in 3 seconds!
      setLogoTaps([])
      if (profile?.role === 'admin' || profile?.role === 'developer') {
        alert('Welcome back, staff. Accessing Admin Portal...')
        navigate('/admin')
      } else {
        alert('Secret administrative tap sequence recognized. Please login with an admin or developer account.')
        navigate('/login')
      }
    } else {
      setLogoTaps(updatedTaps)
    }
  }

  return (
    <header className="fixed top-0 w-full z-50 bg-surface h-16 flex justify-between items-center px-margin-mobile md:px-margin-desktop transition-all duration-300 border-b border-outline-variant/20" id="top-bar">
      <div 
        onClick={handleLogoClick}
        className="flex items-center gap-xs cursor-pointer select-none active:scale-95 transition-transform"
        title="Bismillah Store Logo"
      >
        <span className="material-symbols-outlined text-primary text-2xl" data-icon="storefront">storefront</span>
        <h1 className="font-headline font-bold text-headline-md text-primary">Bismillah Store</h1>
      </div>
      
      {/* Desktop Nav Items */}
      <nav className="hidden md:flex items-center gap-md">
        <button 
          onClick={() => navigate('/')} 
          className={`font-label-md hover:text-primary transition-colors ${currentPath === '/' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
        >
          Home
        </button>
        <button 
          onClick={() => navigate('/products')} 
          className={`font-label-md hover:text-primary transition-colors ${currentPath.startsWith('/products') ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
        >
          Shop
        </button>
        {user && (
          <button 
            onClick={() => navigate('/orders')} 
            className={`font-label-md hover:text-primary transition-colors ${currentPath === '/orders' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
          >
            My Orders
          </button>
        )}
      </nav>

      <div className="flex items-center gap-sm">
        {/* Cart Button */}
        <button 
          onClick={() => navigate('/cart')} 
          className="p-xs rounded-full hover:bg-secondary-container/50 transition-colors active:scale-95 relative flex items-center"
        >
          <span className="material-symbols-outlined text-on-surface-variant" data-icon="shopping_cart">shopping_cart</span>
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-on-primary text-[10px] flex items-center justify-center rounded-full font-bold">
              {cartCount}
            </span>
          )}
        </button>

        {/* User Account / Auth */}
        {user ? (
          <div className="flex items-center gap-xs">
            <button 
              onClick={() => navigate('/account')} 
              className={`p-xs rounded-full hover:bg-secondary-container/50 transition-colors active:scale-95 flex items-center ${currentPath === '/account' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
              title="My Account"
            >
              <span className="material-symbols-outlined" data-icon="person">person</span>
            </button>
            {(profile?.role === 'admin' || profile?.role === 'developer') && (
              <button 
                onClick={() => navigate('/admin')}
                className="text-xs bg-primary-container text-on-primary-container font-semibold px-2 py-1 rounded"
                title="Go to Admin Panel"
              >
                Admin
              </button>
            )}
            <button 
              onClick={signOut} 
              className="text-xs text-error hover:underline ml-xs font-medium"
            >
              Sign Out
            </button>
          </div>
        ) : (
          <button 
            onClick={() => navigate('/login')} 
            className="flex items-center gap-1 bg-primary text-on-primary px-4 py-1.5 rounded-full text-sm font-semibold hover:bg-primary-container hover:text-on-primary-container transition-colors"
          >
            <span className="material-symbols-outlined text-sm" data-icon="login">login</span>
            Login
          </button>
        )}
      </div>
    </header>
  )
}
