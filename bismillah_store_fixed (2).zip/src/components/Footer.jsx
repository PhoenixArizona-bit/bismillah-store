import React from 'react'
import { useAuth } from '../context/AuthContext'

export const Footer = ({ currentPath, navigate }) => {
  const { user } = useAuth()

  return (
    <>
      {/* Desktop Footer */}
      <footer className="bg-surface-container-low border-t border-outline-variant/20 py-12 px-margin-mobile md:px-margin-desktop mt-20 mb-16 md:mb-0">
        <div className="max-w-[1280px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-gutter text-on-surface">
          <div>
            <div className="flex items-center gap-xs mb-sm">
              <span className="material-symbols-outlined text-primary text-2xl" data-icon="storefront">storefront</span>
              <span className="font-headline font-bold text-headline-md text-primary">Bismillah Store</span>
            </div>
            <p className="text-on-surface-variant font-label-sm leading-relaxed">
              Premium selections for your daily household needs, organic foods, electronics, fashion, and more. Trusted and transparent shopping experience.
            </p>
          </div>
          <div>
            <h4 className="font-headline font-semibold mb-sm text-primary">Quick Links</h4>
            <ul className="space-y-xs font-label-md">
              <li><button onClick={() => navigate('/')} className="hover:text-primary transition-colors text-on-surface-variant">Home</button></li>
              <li><button onClick={() => navigate('/products')} className="hover:text-primary transition-colors text-on-surface-variant">Shop</button></li>
              {user && (
                <>
                  <li><button onClick={() => navigate('/orders')} className="hover:text-primary transition-colors text-on-surface-variant">My Orders</button></li>
                  <li><button onClick={() => navigate('/account')} className="hover:text-primary transition-colors text-on-surface-variant">Account Settings</button></li>
                </>
              )}
            </ul>
          </div>
          <div>
            <h4 className="font-headline font-semibold mb-sm text-primary">Support</h4>
            <ul className="space-y-xs font-label-md text-on-surface-variant">
              <li>Email: contact@bismillahstore.com</li>
              <li>Phone: +92 (300) 123-4567</li>
              <li>Address: Karachi, Pakistan</li>
            </ul>
          </div>
          <div>
            <h4 className="font-headline font-semibold mb-sm text-primary">Secured Manual Payments</h4>
            <p className="text-on-surface-variant font-label-sm leading-relaxed mb-sm">
              Currently accepting payments via Easypaisa and JazzCash with instant manual transaction validation.
            </p>
          </div>
        </div>
        <div className="max-w-[1280px] mx-auto mt-8 pt-6 border-t border-outline-variant/20 flex flex-col md:flex-row justify-between items-center gap-sm">
          <span className="text-label-sm text-on-surface-variant">© {new Date().getFullYear()} Bismillah Store. All rights reserved.</span>
          <span className="text-label-sm text-on-surface-variant flex items-center gap-xs">
            <span className="material-symbols-outlined text-xs text-primary" data-icon="verified">verified</span> Pure shopping experience
          </span>
        </div>
      </footer>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full flex justify-around items-center px-4 py-2 bg-surface shadow-[0_-4px_10px_rgba(0,0,0,0.06)] z-50 rounded-t-xl border-t border-outline-variant/10">
        <button 
          onClick={() => navigate('/')} 
          className={`flex flex-col items-center justify-center rounded-full px-4 py-1.5 transition-all ${currentPath === '/' ? 'bg-primary-container/20 text-primary font-bold scale-105' : 'text-on-surface-variant active:scale-95'}`}
        >
          <span className="material-symbols-outlined" data-icon="home">home</span>
          <span className="text-[10px] font-medium mt-0.5">Home</span>
        </button>
        
        <button 
          onClick={() => navigate('/products')} 
          className={`flex flex-col items-center justify-center rounded-full px-4 py-1.5 transition-all ${currentPath.startsWith('/products') ? 'bg-primary-container/20 text-primary font-bold scale-105' : 'text-on-surface-variant active:scale-95'}`}
        >
          <span className="material-symbols-outlined" data-icon="grid_view">grid_view</span>
          <span className="text-[10px] font-medium mt-0.5">Shop</span>
        </button>
        
        <button 
          onClick={() => navigate('/cart')} 
          className={`flex flex-col items-center justify-center rounded-full px-4 py-1.5 transition-all ${currentPath === '/cart' ? 'bg-primary-container/20 text-primary font-bold scale-105' : 'text-on-surface-variant active:scale-95'}`}
        >
          <span className="material-symbols-outlined" data-icon="shopping_bag">shopping_bag</span>
          <span className="text-[10px] font-medium mt-0.5">Cart</span>
        </button>
        
        <button 
          onClick={() => navigate(user ? '/account' : '/login')} 
          className={`flex flex-col items-center justify-center rounded-full px-4 py-1.5 transition-all ${currentPath === '/account' || currentPath === '/login' ? 'bg-primary-container/20 text-primary font-bold scale-105' : 'text-on-surface-variant active:scale-95'}`}
        >
          <span className="material-symbols-outlined" data-icon="person">person</span>
          <span className="text-[10px] font-medium mt-0.5">Account</span>
        </button>
      </nav>
    </>
  )
}
