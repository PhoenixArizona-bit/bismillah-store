import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useCart } from '../context/CartContext'

const FALLBACK_PRODUCTS = [
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8501",
    name: "Aura Wireless Pro",
    description: "Premium sleek wireless noise-canceling headphones in matte emerald green.",
    price: 249.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBdMVluHZCODe5_mkvaNc7jVMkirAFkoyZQ8bcdeMSjEp4PzByaT29-s0DZ-Rf5e1fbE0eKBtBmHnapFPdSTmIB5VbXoSUZHPTNPExDwTp0ZiX8zjhbCAmopFuLqp3V_kyS6JWc7J9VcF1dF7NejnSw5zihuQf23xFgEHt_xmC85CMuhjcTs0N_TaEUfpXHXo3tR0hF2sLle9W8DqfIAa2pY8kpbAp2PhN6FOrhmLGhNpUAVKzABlnC_1RH3srCZRGWuwQleYf4WAY",
    category_name: "Electronics",
    stock_qty: 12,
    rating: 4.8,
    reviews: 124,
    is_sale: true,
    original_price: 299.00
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8502",
    name: "Organic Extra Virgin Oil",
    description: "Artisanal organic olive oil bottles with elegant labels.",
    price: 18.50,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuAE92w9J68Nyp9lmYgsgt7CQfNqvewWKn12JpeSsGFfgRcaAdC7BqOlvtMWp8VrbEEPTFAkj7z69Fg9L9ESnBe7J161uK4acO0eQO1xDf0jV1tLcHTmrPc5n1lDe97N7owZ7mJ85Dkcazo7HkWCNY2P-RfE7vZLCdj7oLbqUBabl3xWeU4Guf7bv0CIqHPAfuNdaKOIhvOF7snW7GxjNh5k182o2WLTNdV511oevDHQrZklIb3J28XviZNeLFWmICS5bH2Gy1pX57M",
    category_name: "Grocery",
    stock_qty: 45,
    rating: 5.0,
    reviews: 89
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8503",
    name: "Linen Blend Shirt",
    description: "Minimalist cotton linen shirt in a soft sage green color.",
    price: 45.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBqdMWOBZcokiDLMTczffgdTVe27nTHQ-XdfJyVCbR_SE7VrHzlUpyrhoGCDeJBlmKd3_orgpFEoHEgXJ-1bUr2V1k5BccD9iOtkWQJgHtKUWci0_2KMJJ9_t5rRYfrTxrUyDekHd_OqsujfJkvVGrIJPX04iWM24Eie9K787QhKDuvTpC41FyjRi-0zIGTBsmu0lDOsB5vDIPgA0isPDcav8OhHiTJCLm1ttgISZ5XlejPBxuwZ396L4N-2upjZccoBOCIfBFTbxY",
    category_name: "Fashion",
    stock_qty: 8,
    rating: 4.2,
    reviews: 42,
    is_new: true
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8504",
    name: "Eco Glass Flask",
    description: "Minimalist glass water bottle with a bamboo lid and green silicone sleeve.",
    price: 32.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBCkNDvL46cxZQ86qDxs8fXO0VDcxEbso8rllX_njC-fzLrDQQdq-C3i7ovedevr2SzIbX0Nd2jOfXzxiRo8sm_1JRxkf0X3AJDK7ivuH0x-IIYyBl72epT7-7nDu-ZUP5Sj6hq0ko9qxGctZoVrUGC129FhMCHaliGhR-upzne6ewZ1QVwesvpWvxLC33Q6HpB0o11UVAexk-YeybLdQ3n4jRuEDdQNmPUZMSX-2_yXxCcFk0-674Pm2gmJrEEvVXQoaB9g4uBD7E",
    category_name: "Home Care",
    stock_qty: 24,
    rating: 4.9,
    reviews: 216
  }
]

const FALLBACK_CATEGORIES = ["All", "Grocery", "Electronics", "Fashion", "Home Care", "Toys", "Health"]

export const ProductListing = ({ currentPath, navigate }) => {
  const { addToCart } = useCart()
  const [products, setProducts] = useState(import.meta.env.DEV ? FALLBACK_PRODUCTS : [])
  const [categories, setCategories] = useState(import.meta.env.DEV ? FALLBACK_CATEGORIES : [])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [priceRange, setPriceRange] = useState(500) // Max price slider limit
  const [toastMessage, setToastMessage] = useState('')

  useEffect(() => {
    // Check url search params for pre-selected category
    const params = new URLSearchParams(window.location.search)
    const catParam = params.get('category')
    if (catParam) {
      setSelectedCategory(catParam)
    }
  }, [window.location.search])

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true)
        
        // Fetch categories first
        const { data: catData } = await supabase.from('categories').select('name')
        if (catData && catData.length > 0) {
          setCategories(['All', ...catData.map(c => c.name)])
        }

        // Fetch products
        let query = supabase.from('products').select('*, categories(name)').eq('is_active', true)
        
        const { data, error } = await query
        if (!error && data && data.length > 0) {
          setProducts(data.map(p => ({
            ...p,
            category_name: p.categories?.name || 'General'
          })))
        }
      } catch (err) {
        console.error('Error fetching products:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  const triggerToast = (msg) => {
    setToastMessage(msg)
    setTimeout(() => setToastMessage(''), 2000)
  }

  const handleAddToCart = (product, e) => {
    e.stopPropagation()
    addToCart(product, 1)
    triggerToast(`${product.name} added to cart!`)
  }

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.description?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'All' || p.category_name === selectedCategory
    const matchesPrice = parseFloat(p.price) <= priceRange
    return matchesSearch && matchesCategory && matchesPrice
  })

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto overflow-x-hidden text-left px-margin-mobile md:px-margin-desktop">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-20 right-4 bg-on-primary-container text-white px-md py-sm rounded-lg shadow-xl z-[60] animate-bounce">
          {toastMessage}
        </div>
      )}

      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Store Catalog</h2>
        <p className="text-on-surface-variant font-label-md">Browse our entire range of high-quality items</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-gutter items-start">
        {/* Sidebar Filters */}
        <aside className="bg-surface-container-low p-md rounded-2xl border border-outline-variant/30 space-y-md">
          {/* Search bar */}
          <div>
            <label className="block text-label-sm font-semibold text-on-surface mb-xs">Search Products</label>
            <div className="relative">
              <input 
                type="text" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-surface-container-lowest border-none rounded-full pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                placeholder="Search..."
              />
              <span className="material-symbols-outlined absolute left-3 top-2.5 text-on-surface-variant text-sm">search</span>
            </div>
          </div>

          {/* Categories list */}
          <div>
            <span className="block text-label-sm font-semibold text-on-surface mb-xs">Categories</span>
            <div className="flex flex-wrap lg:flex-col gap-xs">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-sm py-1.5 rounded-full text-left font-label-md transition-all ${selectedCategory === cat ? 'bg-primary text-on-primary font-bold' : 'bg-surface-container-lowest text-on-surface-variant hover:bg-secondary-container/50'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range filter */}
          <div>
            <label className="block text-label-sm font-semibold text-on-surface mb-xs">Max Price: Rs {priceRange}</label>
            <input 
              type="range" 
              min="5" 
              max="1000" 
              step="5"
              value={priceRange}
              onChange={(e) => setPriceRange(parseInt(e.target.value))}
              className="w-full accent-primary bg-surface-container-highest rounded-lg appearance-none h-2"
            />
            <div className="flex justify-between text-[10px] text-on-surface-variant mt-1 font-semibold">
              <span>Rs 5</span>
              <span>Rs 1,000</span>
            </div>
          </div>
        </aside>

        {/* Product Grid Area */}
        <div className="lg:col-span-3">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 bg-surface-container-lowest rounded-2xl border border-outline-variant/20">
              <span className="material-symbols-outlined text-[80px] text-on-surface-variant mb-md">shopping_cart_off</span>
              <p className="font-headline font-semibold text-headline-md text-on-surface">No products found</p>
              <p className="text-on-surface-variant font-label-md mt-xs">Try adjusting your filters or search query.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-gutter">
              {filteredProducts.map((prod) => (
                <article 
                  key={prod.id} 
                  onClick={() => navigate(`/product/${prod.id}`)}
                  className="bg-surface-container-lowest rounded-xl border border-outline-variant/30 overflow-hidden shadow-sm hover:shadow-md transition-all group cursor-pointer"
                >
                  <div className="relative h-56 overflow-hidden">
                    {prod.stock_qty <= 0 && (
                      <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-10 flex items-center justify-center">
                        <span className="bg-error text-on-error text-xs font-bold px-3 py-1 rounded-full uppercase">Out of Stock</span>
                      </div>
                    )}
                    <button className="absolute top-sm right-sm z-10 w-8 h-8 rounded-full bg-white/80 backdrop-blur shadow-sm flex items-center justify-center text-on-surface-variant hover:text-error transition-colors">
                      <span className="material-symbols-outlined text-lg" data-icon="favorite">favorite</span>
                    </button>
                    <div 
                      className="w-full h-full bg-cover bg-center transition-transform duration-500 group-hover:scale-110" 
                      style={{ backgroundImage: `url('${prod.image_url}')` }}
                    ></div>
                  </div>
                  <div className="p-md">
                    <span className="text-on-surface-variant font-label-sm mb-xs block">{prod.category_name}</span>
                    <h3 className="font-headline font-semibold text-headline-md text-on-surface mb-xs truncate">{prod.name}</h3>
                    <div className="flex items-center gap-xs mb-md">
                      <div className="flex text-[#FFB800]">
                        {[...Array(5)].map((_, i) => (
                          <span 
                            key={i} 
                            className="material-symbols-outlined text-sm" 
                            data-icon="star"
                            style={{ fontVariationSettings: i < Math.floor(prod.rating || 5) ? "'FILL' 1" : "'FILL' 0" }}
                          >
                            star
                          </span>
                        ))}
                      </div>
                      <span className="text-on-surface-variant font-label-sm">({prod.reviews || 45})</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-col">
                        <span className="text-primary font-bold text-headline-md">Rs {parseFloat(prod.price).toFixed(2)}</span>
                      </div>
                      <button 
                        onClick={(e) => handleAddToCart(prod, e)}
                        disabled={prod.stock_qty <= 0}
                        className="w-12 h-12 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-primary-container hover:text-on-primary-container transition-all active:scale-90 disabled:bg-secondary-container disabled:text-on-secondary-container"
                      >
                        <span className="material-symbols-outlined">{prod.stock_qty <= 0 ? 'block' : 'add_shopping_cart'}</span>
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
