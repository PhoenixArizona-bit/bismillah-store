import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'

export const DevPortal = ({ navigate }) => {
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState('')

  // Settings states
  const [jcNumber, setJcNumber] = useState('')
  const [jcName, setJcName] = useState('')
  const [epNumber, setEpNumber] = useState('')
  const [epName, setEpName] = useState('')

  const [storeName, setStoreName] = useState('Bismillah Store')
  const [primaryColor, setPrimaryColor] = useState('#006c49')

  useEffect(() => {
    const fetchDevSettings = async () => {
      try {
        setLoading(true)
        const { data, error } = await supabase
          .from('store_settings')
          .select('*')
          .eq('id', 1)
          .single()

        if (error) throw error

        if (data) {
          if (data.payment_account_details) {
            setJcNumber(data.payment_account_details.jazzcash?.account_number || '')
            setJcName(data.payment_account_details.jazzcash?.account_name || '')
            setEpNumber(data.payment_account_details.easypaisa?.account_number || '')
            setEpName(data.payment_account_details.easypaisa?.account_name || '')
          }
          if (data.theme_config) {
            setStoreName(data.theme_config.store_name || 'Bismillah Store')
            setPrimaryColor(data.theme_config.primary_color || '#006c49')
          }
        }
      } catch (err) {
        console.error('Developer settings load error:', err)
        setErrorMsg(err.message || 'Permission denied. Ensure your role is elevated to developer.')
      } finally {
        setLoading(false)
      }
    }

    fetchDevSettings()
  }, [])

  const handleSave = async (e) => {
    e.preventDefault()
    setErrorMsg('')
    setSuccessMsg('')

    const updatedAccountDetails = {
      jazzcash: { account_number: jcNumber.trim(), account_name: jcName.trim() },
      easypaisa: { account_number: epNumber.trim(), account_name: epName.trim() }
    }

    const updatedThemeConfig = {
      store_name: storeName.trim(),
      primary_color: primaryColor.trim()
    }

    try {
      const { error } = await supabase
        .from('store_settings')
        .update({
          payment_account_details: updatedAccountDetails,
          theme_config: updatedThemeConfig
        })
        .eq('id', 1)

      if (error) throw error
      setSuccessMsg('System configuration and credentials saved successfully!')
    } catch (err) {
      console.error('Error saving developer configurations:', err)
      setErrorMsg(err.message || 'Error occurred while saving configurations.')
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[800px] mx-auto text-left px-margin-mobile">
      <div className="pt-md pb-lg flex justify-between items-center">
        <div>
          <h2 className="font-headline font-semibold text-headline-lg text-red-600">Developer configuration portal</h2>
          <p className="text-on-surface-variant font-label-md">Edit secured payment account keys, branding settings, and general system variables</p>
        </div>
        <button 
          onClick={() => navigate('/admin')}
          className="bg-surface-container-lowest border border-outline-variant hover:bg-secondary-container/50 text-on-surface px-md py-2 rounded-full font-bold active:scale-95 transition-all text-xs"
        >
          Back to Admin
        </button>
      </div>

      {errorMsg && (
        <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
          {errorMsg}
        </div>
      )}

      {successMsg && (
        <div className="bg-primary-container/20 text-on-primary-container p-sm rounded-lg text-xs font-semibold mb-md border border-primary/20">
          {successMsg}
        </div>
      )}

      {loading ? (
        <div className="text-center py-10">
          <span className="material-symbols-outlined text-[48px] text-primary animate-spin">sync</span>
        </div>
      ) : (
        <form onSubmit={handleSave} className="space-y-md">
          {/* Card 1: Payment Numbers Editor */}
          <div className="bg-surface-container-low p-md rounded-2xl border border-red-500/20 space-y-md shadow-sm">
            <h3 className="font-headline font-semibold text-headline-md text-on-surface border-b border-outline-variant/10 pb-xs">
              Manual Payment Wallet Configuration (Dev Role Only)
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
              {/* JazzCash Number */}
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">JazzCash Account Number</label>
                <input 
                  type="text" 
                  required
                  value={jcNumber}
                  onChange={(e) => setJcNumber(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
                  placeholder="03001234567"
                />
              </div>
              
              {/* JazzCash Name */}
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">JazzCash Account Name / Title</label>
                <input 
                  type="text" 
                  required
                  value={jcName}
                  onChange={(e) => setJcName(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                  placeholder="e.g. Bismillah Store"
                />
              </div>

              {/* Easypaisa Number */}
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Easypaisa Account Number</label>
                <input 
                  type="text" 
                  required
                  value={epNumber}
                  onChange={(e) => setEpNumber(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
                  placeholder="03159876543"
                />
              </div>

              {/* Easypaisa Name */}
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Easypaisa Account Name / Title</label>
                <input 
                  type="text" 
                  required
                  value={epName}
                  onChange={(e) => setEpName(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                  placeholder="e.g. Bismillah Store"
                />
              </div>
            </div>
          </div>

          {/* Card 2: Theme Settings */}
          <div className="bg-surface-container-low p-md rounded-2xl border border-red-500/20 space-y-md shadow-sm">
            <h3 className="font-headline font-semibold text-headline-md text-on-surface border-b border-outline-variant/10 pb-xs">
              Branding & Layout Configuration
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Store Display Name</label>
                <input 
                  type="text" 
                  required
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                />
              </div>

              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Primary Accent Color Code</label>
                <div className="flex gap-xs">
                  <input 
                    type="color" 
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="w-12 h-10 border-none rounded cursor-pointer bg-transparent"
                  />
                  <input 
                    type="text" 
                    required
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="flex-1 bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-red-600 hover:bg-red-700 text-white py-sm rounded-full font-bold active:scale-95 transition-all flex items-center justify-center gap-xs"
          >
            <span className="material-symbols-outlined">save</span> Save Dev Configurations
          </button>
        </form>
      )}
    </main>
  )
}
