import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export const Auth = ({ navigate }) => {
  const { signIn, signUp, user } = useAuth()
  const [isSignUp, setIsSignUp] = useState(false)
  
  // Form fields
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')
  
  // Status states
  const [loading, setLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')

  // Redirect if already logged in
  if (user) {
    setTimeout(() => navigate('/'), 500)
    return (
      <div className="pt-24 pb-20 text-center">
        <span className="material-symbols-outlined text-[64px] text-primary">done</span>
        <p className="mt-md font-headline font-semibold text-on-surface">Authenticated. Redirecting you home...</p>
      </div>
    )
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setErrorMessage('')
    setSuccessMessage('')

    try {
      if (isSignUp) {
        await signUp(email, password, {
          full_name: fullName,
          phone: phone
        })
        setSuccessMessage('Registration successful! Please check your email for verification link, or try signing in if auto-approved.')
        setIsSignUp(false)
      } else {
        await signIn(email, password)
        setSuccessMessage('Logged in successfully! Redirecting...')
        setTimeout(() => navigate('/'), 1000)
      }
    } catch (err) {
      console.error('Auth action error:', err)
      setErrorMessage(err.message || 'An error occurred during authentication.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[480px] mx-auto text-left px-margin-mobile">
      <div className="bg-surface-container-low p-xl rounded-2xl border border-outline-variant/30 mt-lg shadow-sm">
        <div className="text-center mb-lg">
          <span className="material-symbols-outlined text-[48px] text-primary" data-icon="storefront">storefront</span>
          <h2 className="font-headline font-bold text-headline-lg text-on-surface mt-xs">
            {isSignUp ? 'Create an Account' : 'Welcome Back'}
          </h2>
          <p className="text-on-surface-variant font-label-md mt-xs">
            {isSignUp ? 'Register to start shopping in Bismillah Store' : 'Sign in to access your orders and account'}
          </p>
        </div>

        {errorMessage && (
          <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
            {errorMessage}
          </div>
        )}

        {successMessage && (
          <div className="bg-primary-container/20 text-on-primary-container p-sm rounded-lg text-xs font-semibold mb-md border border-primary/20">
            {successMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-md">
          {isSignUp && (
            <>
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Full Name</label>
                <input 
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-label-sm font-bold text-on-surface mb-xs">Mobile Number</label>
                <input 
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                  placeholder="03001234567"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Email Address</label>
            <input 
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
              placeholder="name@example.com"
            />
          </div>

          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Password</label>
            <input 
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container py-sm rounded-full font-bold active:scale-95 transition-all flex items-center justify-center gap-xs disabled:bg-secondary-container disabled:text-on-secondary-container"
          >
            {loading ? (
              <span className="material-symbols-outlined text-sm animate-spin">sync</span>
            ) : (
              isSignUp ? 'Register Account' : 'Sign In'
            )}
          </button>
        </form>

        <div className="mt-lg pt-md border-t border-outline-variant/20 text-center">
          <button 
            onClick={() => { setIsSignUp(!isSignUp); setErrorMessage(''); setSuccessMessage(''); }}
            className="text-primary font-bold font-label-md hover:underline"
          >
            {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
          </button>
        </div>
      </div>
    </main>
  )
}
