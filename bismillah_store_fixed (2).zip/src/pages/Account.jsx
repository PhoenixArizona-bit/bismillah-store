import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export const Account = ({ navigate }) => {
  const { user, profile, updateProfileDetails } = useAuth()

  // Form states
  const [fullName, setFullName] = useState(profile?.full_name || '')
  const [phone, setPhone] = useState(profile?.phone || '')
  const [address, setAddress] = useState(profile?.address || '')

  // Status states
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState('')

  if (!user) {
    navigate('/login')
    return null
  }

  const handleSave = async (e) => {
    e.preventDefault()
    setLoading(true)
    setErrorMsg('')
    setSuccessMsg('')

    try {
      await updateProfileDetails({
        full_name: fullName,
        phone: phone,
        address: address
      })
      setSuccessMsg('Profile updated successfully!')
    } catch (err) {
      console.error('Profile update error:', err)
      setErrorMsg(err.message || 'Error saving details.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[640px] mx-auto text-left px-margin-mobile">
      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Account Settings</h2>
        <p className="text-on-surface-variant font-label-md">Manage your profile, phone number, and delivery address</p>
      </div>

      <div className="bg-surface-container-low p-xl rounded-2xl border border-outline-variant/30 shadow-sm">
        {errorMsg && (
          <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
            {errorMsg}
          </div>
        )}

        {successMsg && (
          <div className="bg-primary-container/20 text-on-primary-container p-sm rounded-lg text-xs font-semibold mb-md border border-primary/20">
            {successMsg}
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-md">
          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Email Address</label>
            <input 
              type="text"
              disabled
              value={user.email}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/10 rounded-lg p-sm text-on-surface-variant cursor-not-allowed opacity-70"
            />
            <span className="text-[10px] text-on-surface-variant mt-1 block">Your email cannot be changed.</span>
          </div>

          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Full Name</label>
            <input 
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
              placeholder="Your full name"
            />
          </div>

          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Mobile Number</label>
            <input 
              type="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
              placeholder="e.g. 03001234567"
            />
          </div>

          <div>
            <label className="block text-label-sm font-bold text-on-surface mb-xs">Default Shipping Address</label>
            <textarea 
              rows="3"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
              placeholder="Complete address (house, street, city)"
            ></textarea>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container py-sm rounded-full font-bold active:scale-95 transition-all flex items-center justify-center gap-xs disabled:bg-secondary-container"
          >
            {loading ? (
              <span className="material-symbols-outlined text-sm animate-spin">sync</span>
            ) : (
              'Save Profile Changes'
            )}
          </button>
        </form>
      </div>
    </main>
  )
}
