import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'

export const AdminPayments = ({ navigate }) => {
  const [activeMethods, setActiveMethods] = useState({ jazzcash: true, easypaisa: true })
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState('')

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        setLoading(true)
        const { data, error } = await supabase
          .from('store_settings')
          .select('payment_methods_active')
          .eq('id', 1)
          .single()

        if (!error && data && data.payment_methods_active) {
          setActiveMethods(data.payment_methods_active)
        }
      } catch (err) {
        console.error('Error fetching settings:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchSettings()
  }, [])

  const handleToggle = async (method) => {
    setErrorMsg('')
    setSuccessMsg('')
    
    const updated = {
      ...activeMethods,
      [method]: !activeMethods[method]
    }

    try {
      const { error } = await supabase
        .from('store_settings')
        .update({ payment_methods_active: updated })
        .eq('id', 1)

      if (error) throw error
      
      setActiveMethods(updated)
      setSuccessMsg(`${method === 'jazzcash' ? 'JazzCash' : 'Easypaisa'} status updated successfully!`)
    } catch (err) {
      console.error('Error toggling payment method:', err)
      setErrorMsg(err.message || 'Error occurred while saving.')
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[640px] mx-auto text-left px-margin-mobile">
      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Payment Configuration</h2>
        <p className="text-on-surface-variant font-label-md">Enable or disable manual payment methods for storefront checkouts</p>
      </div>

      {errorMsg && (
        <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
          {errorMsg}
        </div>
      )}

      {successMsg && (
        <div className="bg-primary-container/20 text-on-primary-container p-sm rounded-lg text-xs font-semibold mb-md border border-primary/20">
          {successMsg}
        </div>
      )}

      {loading ? (
        <div className="text-center py-10">
          <span className="material-symbols-outlined text-[48px] text-primary animate-spin">sync</span>
        </div>
      ) : (
        <div className="bg-surface-container-low p-md rounded-2xl border border-outline-variant/30 space-y-md shadow-sm">
          <div className="border-b border-outline-variant/10 pb-xs">
            <h3 className="font-headline font-semibold text-headline-md text-on-surface">Manual Payment Methods</h3>
            <span className="text-[10px] text-on-surface-variant font-semibold">Toggling these controls determines what is displayed at checkout. Note: Account number editing is reserved for developers.</span>
          </div>

          <div className="space-y-sm">
            {/* JazzCash Toggle */}
            <div className="flex items-center justify-between p-sm bg-surface-container-lowest rounded-xl border border-outline-variant/10">
              <div>
                <span className="font-bold text-on-surface block text-sm">JazzCash Wallet Payments</span>
                <span className="text-xs text-on-surface-variant">Status: {activeMethods.jazzcash ? 'Active / Visible' : 'Disabled'}</span>
              </div>
              <button 
                onClick={() => handleToggle('jazzcash')}
                className={`w-14 h-8 rounded-full transition-colors relative flex items-center ${activeMethods.jazzcash ? 'bg-primary' : 'bg-surface-container'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full absolute shadow transition-transform ${activeMethods.jazzcash ? 'translate-x-7' : 'translate-x-1'}`} />
              </button>
            </div>

            {/* Easypaisa Toggle */}
            <div className="flex items-center justify-between p-sm bg-surface-container-lowest rounded-xl border border-outline-variant/10">
              <div>
                <span className="font-bold text-on-surface block text-sm">Easypaisa Wallet Payments</span>
                <span className="text-xs text-on-surface-variant">Status: {activeMethods.easypaisa ? 'Active / Visible' : 'Disabled'}</span>
              </div>
              <button 
                onClick={() => handleToggle('easypaisa')}
                className={`w-14 h-8 rounded-full transition-colors relative flex items-center ${activeMethods.easypaisa ? 'bg-primary' : 'bg-surface-container'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full absolute shadow transition-transform ${activeMethods.easypaisa ? 'translate-x-7' : 'translate-x-1'}`} />
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  )
}
