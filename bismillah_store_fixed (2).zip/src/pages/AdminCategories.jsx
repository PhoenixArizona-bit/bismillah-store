import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'

export const AdminCategories = ({ navigate }) => {
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [name, setName] = useState('')
  const [sortOrder, setSortOrder] = useState('0')
  const [editingCat, setEditingCat] = useState(null)
  
  const [errorMsg, setErrorMsg] = useState('')
  const [successMsg, setSuccessMsg] = useState('')

  const fetchCategories = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('sort_order', { ascending: true })

      if (!error && data) {
        setCategories(data)
      }
    } catch (err) {
      console.error('Error loading admin categories:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchCategories()
  }, [])

  const handleSave = async (e) => {
    e.preventDefault()
    setErrorMsg('')
    setSuccessMsg('')

    if (!name.trim()) {
      setErrorMsg('Category name is required.')
      return
    }

    const payload = {
      name: name.trim(),
      sort_order: parseInt(sortOrder) || 0
    }

    try {
      if (editingCat) {
        const { error } = await supabase
          .from('categories')
          .update(payload)
          .eq('id', editingCat.id)
        if (error) throw error
        setSuccessMsg('Category updated successfully!')
      } else {
        const { error } = await supabase
          .from('categories')
          .insert(payload)
        if (error) throw error
        setSuccessMsg('Category added successfully!')
      }

      setName('')
      setSortOrder('0')
      setEditingCat(null)
      fetchCategories()
    } catch (err) {
      console.error('Error saving category:', err)
      setErrorMsg(err.message || 'Error occurred while saving.')
    }
  }

  const handleEditClick = (cat) => {
    setEditingCat(cat)
    setName(cat.name)
    setSortOrder(cat.sort_order.toString())
    setErrorMsg('')
    setSuccessMsg('')
  }

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this category? This might affect products categorized under it.')) return
    
    try {
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id)
      if (error) throw error
      setSuccessMsg('Category deleted successfully!')
      fetchCategories()
    } catch (err) {
      console.error('Error deleting category:', err)
      setErrorMsg(err.message || 'Error occurred while deleting.')
    }
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[960px] mx-auto text-left px-margin-mobile">
      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Category Department Management</h2>
        <p className="text-on-surface-variant font-label-md">Manage product navigation nodes and sorting priority</p>
      </div>

      {errorMsg && (
        <div className="bg-error-container text-on-error-container p-sm rounded-lg text-xs font-semibold mb-md border border-error/20">
          {errorMsg}
        </div>
      )}

      {successMsg && (
        <div className="bg-primary-container/20 text-on-primary-container p-sm rounded-lg text-xs font-semibold mb-md border border-primary/20">
          {successMsg}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-12 gap-gutter items-start">
        {/* Form Container */}
        <div className="md:col-span-5 bg-surface-container-low p-md rounded-2xl border border-outline-variant/30 space-y-md">
          <h3 className="font-headline font-semibold text-headline-md text-on-surface">
            {editingCat ? `Edit: ${editingCat.name}` : 'Add Category'}
          </h3>
          <form onSubmit={handleSave} className="space-y-sm">
            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Category Name</label>
              <input 
                type="text" 
                required 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface"
                placeholder="e.g. Fresh Fruits"
              />
            </div>

            <div>
              <label className="block text-label-sm font-bold text-on-surface mb-xs">Sort Order / Priority</label>
              <input 
                type="number" 
                required 
                value={sortOrder} 
                onChange={(e) => setSortOrder(e.target.value)} 
                className="w-full bg-surface-container-lowest border-none border-b-2 border-outline-variant/30 rounded-lg p-sm focus:ring-2 focus:ring-primary-container text-on-surface font-mono"
                placeholder="0"
              />
              <span className="text-[10px] text-on-surface-variant block mt-0.5">Lower numbers display first.</span>
            </div>

            <div className="flex gap-xs pt-xs">
              {editingCat && (
                <button 
                  type="button" 
                  onClick={() => { setEditingCat(null); setName(''); setSortOrder('0'); }}
                  className="flex-1 bg-surface-container-lowest border border-outline-variant text-on-surface py-2 rounded-full font-bold active:scale-95"
                >
                  Cancel
                </button>
              )}
              <button 
                type="submit" 
                className="flex-1 bg-primary text-on-primary py-2 rounded-full font-bold active:scale-95 hover:bg-primary-container hover:text-on-primary-container"
              >
                {editingCat ? 'Save Changes' : 'Create Category'}
              </button>
            </div>
          </form>
        </div>

        {/* Data Table */}
        <div className="md:col-span-7 bg-surface-container-lowest rounded-2xl border border-outline-variant/20 overflow-x-auto shadow-sm">
          {loading ? (
            <div className="text-center py-10">
              <span className="material-symbols-outlined text-[48px] text-primary animate-spin">sync</span>
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-surface-container-low border-b border-outline-variant/20 text-xs font-bold text-on-surface-variant">
                  <th className="py-sm px-md">Sort Order</th>
                  <th className="py-sm px-md">Name</th>
                  <th className="py-sm px-md text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-outline-variant/10 text-sm">
                {categories.map(cat => (
                  <tr key={cat.id} className="hover:bg-secondary-container/10 transition-colors">
                    <td className="py-sm px-md font-mono font-semibold text-primary">{cat.sort_order}</td>
                    <td className="py-sm px-md font-bold text-on-surface">{cat.name}</td>
                    <td className="py-sm px-md text-right space-x-xs">
                      <button 
                        onClick={() => handleEditClick(cat)}
                        className="text-xs bg-secondary-container text-on-secondary-container hover:bg-primary-container hover:text-on-primary-container px-sm py-1 rounded font-semibold transition-all"
                      >
                        Edit
                      </button>
                      <button 
                        onClick={() => handleDelete(cat.id)}
                        className="text-xs bg-red-50 text-red-600 hover:bg-red-100 px-sm py-1 rounded font-semibold transition-all"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </main>
  )
}
