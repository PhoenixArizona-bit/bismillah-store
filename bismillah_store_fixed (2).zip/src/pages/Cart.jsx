import React from 'react'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'

export const Cart = ({ navigate }) => {
  const { user } = useAuth()
  const { cart, updateQuantity, removeFromCart, cartTotal } = useCart()

  const handleCheckoutClick = () => {
    if (!user) {
      alert('You must log in to checkout.')
      navigate('/login')
    } else {
      navigate('/checkout')
    }
  }

  if (cart.length === 0) {
    return (
      <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto text-center px-margin-mobile">
        <div className="py-20 bg-surface-container-low rounded-2xl border border-outline-variant/20 mt-md">
          <span className="material-symbols-outlined text-[80px] text-primary mb-md">shopping_cart_off</span>
          <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Your Cart is Empty</h2>
          <p className="text-on-surface-variant font-label-md mt-xs max-w-md mx-auto">
            Browse our catalog to find fresh organic grocery items, electronics, fashion, and other sustainable lifestyle goods.
          </p>
          <button 
            onClick={() => navigate('/products')} 
            className="mt-lg bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container px-lg py-sm rounded-full font-bold active:scale-95 transition-all"
          >
            Start Shopping
          </button>
        </div>
      </main>
    )
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto text-left px-margin-mobile md:px-margin-desktop">
      <div className="pt-md pb-lg">
        <h2 className="font-headline font-semibold text-headline-lg text-on-surface">Your Shopping Cart</h2>
        <p className="text-on-surface-variant font-label-md">Review items selected for your order</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
        {/* Cart items list */}
        <div className="lg:col-span-8 space-y-sm">
          {cart.map((item) => (
            <div 
              key={item.id} 
              className="bg-surface-container-lowest p-md rounded-2xl border border-outline-variant/20 flex items-center justify-between gap-md"
            >
              {/* Product thumb */}
              <div 
                className="w-20 h-20 bg-cover bg-center rounded-xl border border-outline-variant/30 flex-shrink-0"
                style={{ backgroundImage: `url('${item.image_url}')` }}
              ></div>

              {/* Title & category */}
              <div className="flex-1 min-w-0">
                <span className="text-on-surface-variant font-label-sm uppercase tracking-wider">{item.category_name}</span>
                <h3 className="font-headline font-semibold text-headline-md text-on-surface truncate">{item.name}</h3>
                <span className="text-primary font-bold font-headline">Rs {parseFloat(item.price).toFixed(2)} each</span>
              </div>

              {/* Quantity adjust */}
              <div className="flex items-center bg-surface-container-low rounded-full px-sm py-1">
                <button 
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  className="w-7 h-7 rounded-full flex items-center justify-center font-bold hover:bg-secondary-container/50 text-on-surface-variant"
                >
                  -
                </button>
                <span className="px-md font-headline font-bold text-on-surface w-10 text-center">{item.quantity}</span>
                <button 
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  className="w-7 h-7 rounded-full flex items-center justify-center font-bold hover:bg-secondary-container/50 text-on-surface-variant"
                >
                  +
                </button>
              </div>

              {/* Remove action */}
              <button 
                onClick={() => removeFromCart(item.id)}
                className="text-error hover:text-error/80 p-xs"
                title="Remove item"
              >
                <span className="material-symbols-outlined">delete</span>
              </button>
            </div>
          ))}
        </div>

        {/* Order summary card */}
        <div className="lg:col-span-4 bg-surface-container-low p-md rounded-2xl border border-outline-variant/20 space-y-md">
          <h3 className="font-headline font-semibold text-headline-md text-on-surface">Order Summary</h3>
          <div className="space-y-sm">
            <div className="flex justify-between text-on-surface-variant font-label-md">
              <span>Subtotal</span>
              <span>Rs {cartTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-on-surface-variant font-label-md">
              <span>Delivery</span>
              <span className="text-primary-container font-semibold">FREE</span>
            </div>
            <div className="border-t border-outline-variant/20 pt-sm flex justify-between text-on-surface font-headline font-bold text-headline-md">
              <span>Total</span>
              <span className="text-primary">Rs {cartTotal.toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-primary-container/10 p-sm rounded-xl text-xs text-on-primary-container border border-primary-container/20">
            <span className="material-symbols-outlined text-sm align-middle mr-xs">info</span>
            Payments are made manually using JazzCash / Easypaisa. You will enter your Transaction ID on the next screen.
          </div>

          <button 
            onClick={handleCheckoutClick}
            className="w-full bg-primary text-on-primary hover:bg-primary-container hover:text-on-primary-container py-sm rounded-full font-bold active:scale-95 transition-all flex items-center justify-center gap-xs shadow-md shadow-primary/10"
          >
            Proceed to Checkout
          </button>
        </div>
      </div>
    </main>
  )
}
