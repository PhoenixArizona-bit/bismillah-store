import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useCart } from '../context/CartContext'

// Fallback seed data in case Supabase tables are empty
const FALLBACK_PRODUCTS = [
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8501",
    name: "Aura Wireless Pro",
    description: "Premium sleek wireless noise-canceling headphones in matte emerald green.",
    price: 249.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBdMVluHZCODe5_mkvaNc7jVMkirAFkoyZQ8bcdeMSjEp4PzByaT29-s0DZ-Rf5e1fbE0eKBtBmHnapFPdSTmIB5VbXoSUZHPTNPExDwTp0ZiX8zjhbCAmopFuLqp3V_kyS6JWc7J9VcF1dF7NejnSw5zihuQf23xFgEHt_xmC85CMuhjcTs0N_TaEUfpXHXo3tR0hF2sLle9W8DqfIAa2pY8kpbAp2PhN6FOrhmLGhNpUAVKzABlnC_1RH3srCZRGWuwQleYf4WAY",
    category_name: "Electronics",
    stock_qty: 12,
    rating: 4.8,
    reviews: 124,
    is_sale: true,
    original_price: 299.00
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8502",
    name: "Organic Extra Virgin Oil",
    description: "Artisanal organic olive oil bottles with elegant labels.",
    price: 18.50,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuAE92w9J68Nyp9lmYgsgt7CQfNqvewWKn12JpeSsGFfgRcaAdC7BqOlvtMWp8VrbEEPTFAkj7z69Fg9L9ESnBe7J161uK4acO0eQO1xDf0jV1tLcHTmrPc5n1lDe97N7owZ7mJ85Dkcazo7HkWCNY2P-RfE7vZLCdj7oLbqUBabl3xWeU4Guf7bv0CIqHPAfuNdaKOIhvOF7snW7GxjNh5k182o2WLTNdV511oevDHQrZklIb3J28XviZNeLFWmICS5bH2Gy1pX57M",
    category_name: "Grocery",
    stock_qty: 45,
    rating: 5.0,
    reviews: 89
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8503",
    name: "Linen Blend Shirt",
    description: "Minimalist cotton linen shirt in a soft sage green color.",
    price: 45.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBqdMWOBZcokiDLMTczffgdTVe27nTHQ-XdfJyVCbR_SE7VrHzlUpyrhoGCDeJBlmKd3_orgpFEoHEgXJ-1bUr2V1k5BccD9iOtkWQJgHtKUWci0_2KMJJ9_t5rRYfrTxrUyDekHd_OqsujfJkvVGrIJPX04iWM24Eie9K787QhKDuvTpC41FyjRi-0zIGTBsmu0lDOsB5vDIPgA0isPDcav8OhHiTJCLm1ttgISZ5XlejPBxuwZ396L4N-2upjZccoBOCIfBFTbxY",
    category_name: "Fashion",
    stock_qty: 8,
    rating: 4.2,
    reviews: 42,
    is_new: true
  },
  {
    id: "f1b7d591-628d-4e94-811c-bcde58fa8504",
    name: "Eco Glass Flask",
    description: "Minimalist glass water bottle with a bamboo lid and green silicone sleeve.",
    price: 32.00,
    image_url: "https://lh3.googleusercontent.com/aida-public/AB6AXuBCkNDvL46cxZQ86qDxs8fXO0VDcxEbso8rllX_njC-fzLrDQQdq-C3i7ovedevr2SzIbX0Nd2jOfXzxiRo8sm_1JRxkf0X3AJDK7ivuH0x-IIYyBl72epT7-7nDu-ZUP5Sj6hq0ko9qxGctZoVrUGC129FhMCHaliGhR-upzne6ewZ1QVwesvpWvxLC33Q6HpB0o11UVAexk-YeybLdQ3n4jRuEDdQNmPUZMSX-2_yXxCcFk0-674Pm2gmJrEEvVXQoaB9g4uBD7E",
    category_name: "Home Care",
    stock_qty: 24,
    rating: 4.9,
    reviews: 216
  }
]

const FALLBACK_CATEGORIES = [
  { id: '1', name: 'Grocery', icon: 'grocery' },
  { id: '2', name: 'Electronics', icon: 'devices' },
  { id: '3', name: 'Fashion', icon: 'apparel' },
  { id: '4', name: 'Home Care', icon: 'home_health' },
  { id: '5', name: 'Toys', icon: 'toy_brick' },
  { id: '6', name: 'Health', icon: 'health_and_safety' }
]

export const Home = ({ navigate }) => {
  const { addToCart } = useCart()
  const [products, setProducts] = useState(import.meta.env.DEV ? FALLBACK_PRODUCTS : [])
  const [categories, setCategories] = useState(import.meta.env.DEV ? FALLBACK_CATEGORIES : [])
  const [loading, setLoading] = useState(true)
  const [toastMessage, setToastMessage] = useState('')

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        // 1. Fetch categories
        const { data: catData, error: catError } = await supabase
          .from('categories')
          .select('*')
          .order('sort_order', { ascending: true })

        if (!catError && catData && catData.length > 0) {
          setCategories(catData.map(c => ({
            ...c,
            icon: c.name === 'Grocery' ? 'grocery' :
                  c.name === 'Electronics' ? 'devices' :
                  c.name === 'Fashion' ? 'apparel' :
                  c.name === 'Home Care' ? 'home_health' :
                  c.name === 'Toys' ? 'toy_brick' : 'health_and_safety'
          })))
        }

        // 2. Fetch featured products (is_active = true)
        const { data: prodData, error: prodError } = await supabase
          .from('products')
          .select('*, categories(name)')
          .eq('is_active', true)
          .limit(4)

        if (!prodError && prodData && prodData.length > 0) {
          setProducts(prodData.map(p => ({
            ...p,
            category_name: p.categories?.name || 'General'
          })))
        }
      } catch (err) {
        console.error('Error fetching storefront data:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    // 3. Realtime subscription for products updates
    const subscription = supabase
      .channel('public:products')
      .on('postgres_changes', { event: '*', filter: 'is_active=eq.true', schema: 'public', table: 'products' }, () => {
        fetchData()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [])

  const triggerToast = (msg) => {
    setToastMessage(msg)
    setTimeout(() => setToastMessage(''), 2000)
  }

  const handleAddToCart = (product, e) => {
    e.stopPropagation()
    addToCart(product, 1)
    triggerToast(`${product.name} added to cart!`)
  }

  return (
    <main className="pt-16 pb-24 md:pb-12 max-w-[1280px] mx-auto overflow-x-hidden">
      {/* Toast popup */}
      {toastMessage && (
        <div className="fixed top-20 right-4 bg-on-primary-container text-white px-md py-sm rounded-lg shadow-xl z-[60] animate-bounce">
          {toastMessage}
        </div>
      )}

      {/* Hero Section */}
      <section className="px-margin-mobile md:px-margin-desktop pt-md pb-lg">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-gutter">
          {/* Main Hero Card */}
          <div className="md:col-span-8 relative rounded-xl overflow-hidden h-[320px] md:h-[480px] shadow-sm group">
            <div 
              className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" 
              style={{ backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuDvTxjhwWI-ofYG_MN313PWu2ZIfTfq1-32nurc8MQzGBO1aXCwamthuqUuayCvp5zCw9MDpxTBlppIP1LGa0CRJq9Blo4gvdH_wyam_GLCkGHAAV2aDu9pVlsIPLnvhfKDX5n3IHBkEQKfUtTOy28aX-pO0IHR6ekDeYZ4bHraGr_u7ooU-kY1cibUqWg3nGcK3reL7WBcR9dVseE0Sfv-HSpHTn-vkPBsOtzyQq-i9rB44ffJB9Q7vRCpWPsX4mRCa1c4vBHPpwM')` }}
            ></div>
            <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-black/20 to-transparent z-10"></div>
            <div className="absolute inset-0 z-20 flex flex-col justify-center px-md md:px-xl text-left">
              <span className="text-inverse-primary font-label-md mb-xs animate-pulse">Premium Selection</span>
              <h2 className="text-white font-headline text-headline-lg-mobile md:text-display max-w-md mb-md leading-tight">
                Welcome to Bismillah Store
              </h2>
              <div className="flex gap-sm">
                <button 
                  onClick={() => navigate('/products')} 
                  className="bg-primary-container text-on-primary-container px-md py-sm rounded-full font-label-md font-bold active:scale-95 transition-all shadow-lg shadow-primary-container/20"
                >
                  Shop Now
                </button>
                <button 
                  onClick={() => navigate('/products')} 
                  className="bg-white/20 backdrop-blur-md text-white border border-white/30 px-md py-sm rounded-full font-label-md active:scale-95 transition-all"
                >
                  Explore Categories
                </button>
              </div>
            </div>
          </div>

          {/* Feature Grid Columns */}
          <div className="md:col-span-4 grid grid-rows-2 gap-gutter text-left">
            <div className="bg-tertiary-fixed text-on-tertiary-fixed rounded-xl p-md flex flex-col justify-between relative overflow-hidden group shadow-sm">
              <div className="relative z-10">
                <h3 className="font-headline font-semibold text-headline-md mb-xs">Fresh Arrivals</h3>
                <p className="font-label-sm opacity-80 mb-md">Straight from organic farms to your table.</p>
                <button 
                  onClick={() => navigate('/products')} 
                  className="text-on-tertiary-fixed font-bold font-label-sm border-b-2 border-on-tertiary-fixed pb-0.5 w-fit group-hover:gap-2 flex items-center transition-all"
                >
                  View All <span className="material-symbols-outlined text-sm ml-1" data-icon="arrow_forward">arrow_forward</span>
                </button>
              </div>
              <div className="absolute -right-4 -bottom-4 w-32 h-32 opacity-20 rotate-12 group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-[120px]" data-icon="eco">eco</span>
              </div>
            </div>

            <div className="bg-secondary-container text-on-secondary-container rounded-xl p-md flex flex-col justify-between relative overflow-hidden group shadow-sm">
              <div className="relative z-10">
                <h3 className="font-headline font-semibold text-headline-md mb-xs">Fast Delivery</h3>
                <p className="font-label-sm opacity-80 mb-md">Get your groceries in record time.</p>
                <button 
                  onClick={() => navigate('/orders')} 
                  className="text-on-secondary-container font-bold font-label-sm border-b-2 border-on-secondary-container pb-0.5 w-fit group-hover:gap-2 flex items-center transition-all"
                >
                  Track Order <span className="material-symbols-outlined text-sm ml-1" data-icon="local_shipping">local_shipping</span>
                </button>
              </div>
              <div className="absolute -right-4 -bottom-4 w-32 h-32 opacity-20 -rotate-12 group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-[120px]" data-icon="electric_bolt">electric_bolt</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="px-margin-mobile md:px-margin-desktop mb-lg text-left">
        <div className="flex justify-between items-end mb-md">
          <div>
            <h2 className="font-headline font-semibold text-headline-lg-mobile md:text-headline-lg text-on-surface">Shop by Category</h2>
            <p className="text-on-surface-variant font-label-md">Explore our wide range of curated collections</p>
          </div>
          <button onClick={() => navigate('/products')} className="text-primary font-bold font-label-md hover:underline">View All</button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-gutter">
          {categories.map((cat) => (
            <button 
              key={cat.id} 
              onClick={() => navigate(`/products?category=${encodeURIComponent(cat.name)}`)}
              className="group text-center focus:outline-none"
            >
              <div className="aspect-square bg-surface-container-low rounded-2xl flex flex-col items-center justify-center p-md transition-all duration-300 group-hover:bg-primary-container group-hover:shadow-xl group-hover:shadow-primary-container/10 group-hover:-translate-y-1">
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-sm shadow-sm group-hover:scale-110 transition-transform">
                  <span className="material-symbols-outlined text-primary text-3xl">{cat.icon || 'category'}</span>
                </div>
                <span className="font-label-md text-on-surface group-hover:text-on-primary-container font-bold">{cat.name}</span>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="px-margin-mobile md:px-margin-desktop mb-lg text-left">
        <div className="flex justify-between items-end mb-md">
          <div>
            <h2 className="font-headline font-semibold text-headline-lg-mobile md:text-headline-lg text-on-surface">Featured Products</h2>
            <p className="text-on-surface-variant font-label-md">High-quality picks, exclusively for you</p>
          </div>
          <div className="flex gap-xs">
            <button onClick={() => navigate('/products')} className="p-xs rounded-full border border-outline-variant hover:bg-surface-container transition-colors">
              <span className="material-symbols-outlined text-on-surface-variant" data-icon="chevron_left">chevron_left</span>
            </button>
            <button onClick={() => navigate('/products')} className="p-xs rounded-full border border-outline-variant hover:bg-surface-container transition-colors">
              <span className="material-symbols-outlined text-on-surface-variant" data-icon="chevron_right">chevron_right</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter">
          {products.map((prod) => (
            <article 
              key={prod.id} 
              onClick={() => navigate(`/product/${prod.id}`)}
              className="bg-surface-container-lowest rounded-xl border border-outline-variant/30 overflow-hidden shadow-sm hover:shadow-md transition-all group cursor-pointer text-left"
            >
              <div className="relative h-64 overflow-hidden">
                {prod.is_sale && (
                  <div className="absolute top-sm left-sm z-10 px-xs py-0.5 bg-tertiary-container text-on-tertiary-container rounded font-label-sm font-semibold">Sale</div>
                )}
                {prod.is_new && (
                  <div className="absolute top-sm left-sm z-10 px-xs py-0.5 bg-primary-container text-on-primary-container rounded font-label-sm font-semibold">New</div>
                )}
                <button className="absolute top-sm right-sm z-10 w-8 h-8 rounded-full bg-white/80 backdrop-blur shadow-sm flex items-center justify-center text-on-surface-variant hover:text-error transition-colors">
                  <span className="material-symbols-outlined text-lg" data-icon="favorite">favorite</span>
                </button>
                <div 
                  className="w-full h-full bg-cover bg-center transition-transform duration-500 group-hover:scale-110" 
                  style={{ backgroundImage: `url('${prod.image_url}')` }}
                ></div>
              </div>
              <div className="p-md">
                <span className="text-on-surface-variant font-label-sm mb-xs block">{prod.category_name}</span>
                <h3 className="font-headline font-semibold text-headline-md text-on-surface mb-xs truncate">{prod.name}</h3>
                <div className="flex items-center gap-xs mb-md">
                  <div className="flex text-[#FFB800]">
                    {[...Array(5)].map((_, i) => (
                      <span 
                        key={i} 
                        className="material-symbols-outlined text-sm" 
                        data-icon="star"
                        style={{ fontVariationSettings: i < Math.floor(prod.rating || 5) ? "'FILL' 1" : "'FILL' 0" }}
                      >
                        star
                      </span>
                    ))}
                  </div>
                  <span className="text-on-surface-variant font-label-sm">({prod.reviews || 45})</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-primary font-bold text-headline-md">Rs {parseFloat(prod.price).toFixed(2)}</span>
                    {prod.original_price && (
                      <span className="text-on-surface-variant text-label-sm line-through">Rs {parseFloat(prod.original_price).toFixed(2)}</span>
                    )}
                  </div>
                  <button 
                    onClick={(e) => handleAddToCart(prod, e)}
                    disabled={prod.stock_qty <= 0}
                    className="w-12 h-12 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-primary-container hover:text-on-primary-container transition-all active:scale-90 disabled:bg-secondary-container disabled:text-on-secondary-container"
                  >
                    <span className="material-symbols-outlined">{prod.stock_qty <= 0 ? 'block' : 'add_shopping_cart'}</span>
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Newsletter Trust Section */}
      <section className="px-margin-mobile md:px-margin-desktop mb-md text-left">
        <div className="bg-primary-container/10 rounded-2xl p-xl flex flex-col lg:flex-row items-center gap-lg">
          <div className="flex-1 text-center lg:text-left">
            <h2 className="font-headline font-semibold text-headline-lg text-on-primary-container mb-xs">Join our Green Community</h2>
            <p className="text-on-surface-variant font-body-md mb-md max-w-md mx-auto lg:mx-0">Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.</p>
            <form 
              onSubmit={(e) => { e.preventDefault(); alert('Subscribed successfully!'); }}
              className="flex flex-col sm:flex-row gap-sm max-w-lg mx-auto lg:mx-0"
            >
              <input 
                required
                className="flex-1 bg-surface-container-lowest border-none rounded-full px-md py-sm focus:ring-2 focus:ring-primary-container transition-all text-on-surface" 
                placeholder="Your email address" 
                type="email"
              />
              <button className="bg-primary text-on-primary px-lg py-sm rounded-full font-bold active:scale-95 transition-all" type="submit">Subscribe</button>
            </form>
          </div>
          <div className="hidden lg:block w-72 h-72">
            <div 
              className="w-full h-full bg-cover bg-center rounded-2xl shadow-xl rotate-3" 
              style={{ backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuAPnznH91-wVkCNMKV4JSFBJOttxpQs76F8XMu0J3cS3_TvZKUWskRyqm8ao11FTjPowT7OMjkcO4OPC7BFsoBnF2myHB-vZdeMv2id3kWrhMTiwyJRPTTxev4pYOFoHZw9z_OBEzFYuPaUb9ZLR2YElBd55IqnFTK19BPTLeQ3d8_cbMNJB_8FPcyO_aI40i63NOzcDBFnh4ZL0XuIM0xuLjANCc4Zv_K-mQDt9WHkXZfPTG4_5XpQ2sy4zLoGHpdh6rwczLZc6W4')` }}
            ></div>
          </div>
        </div>
      </section>
    </main>
  )
}
