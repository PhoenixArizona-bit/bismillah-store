import React, { useEffect, useState } from 'react'
import { AuthProvider, useAuth } from './context/AuthContext'
import { CartProvider } from './context/CartContext'

// Shared storefront layout components
import { Navbar } from './components/Navbar'
import { Footer } from './components/Footer'

// Public storefront pages
import { Home } from './pages/Home'
import { ProductListing } from './pages/ProductListing'
import { ProductDetail } from './pages/ProductDetail'
import { Cart } from './pages/Cart'
import { Checkout } from './pages/Checkout'
import { Orders } from './pages/Orders'
import { Account } from './pages/Account'
import { Auth } from './pages/Auth'

// Admin portal pages
import { AdminDashboard } from './pages/AdminDashboard'
import { AdminProducts } from './pages/AdminProducts'
import { AdminCategories } from './pages/AdminCategories'
import { AdminOrders } from './pages/AdminOrders'
import { AdminPayments } from './pages/AdminPayments'

// Developer portal page
import { DevPortal } from './pages/DevPortal'

const MainAppLayout = () => {
  const { user, profile, loading } = useAuth()
  const [currentPath, setCurrentPath] = useState(window.location.pathname)

  // SPA custom router implementation
  const navigate = (path) => {
    window.history.pushState({}, '', path)
    setCurrentPath(path)
    window.scrollTo(0, 0)
  }

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname)
    }
    window.addEventListener('popstate', handlePopState)
    return () => window.removeEventListener('popstate', handlePopState)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-surface text-on-surface">
        <span className="material-symbols-outlined text-[64px] text-primary animate-spin">sync</span>
        <h2 className="mt-md font-headline font-bold text-headline-md">Loading Bismillah Store...</h2>
      </div>
    )
  }

  // Define route rendering logic
  const renderPage = () => {
    // 1. Auth Page
    if (currentPath === '/login') {
      return <Auth navigate={navigate} />
    }

    // 2. Product Detail
    if (currentPath.startsWith('/product/')) {
      const parts = currentPath.split('/')
      const productId = parts[parts.length - 1]
      return <ProductDetail productId={productId} navigate={navigate} />
    }

    // 3. Product Listing
    if (currentPath.startsWith('/products')) {
      return <ProductListing currentPath={currentPath} navigate={navigate} />
    }

    // 4. Cart
    if (currentPath === '/cart') {
      return <Cart navigate={navigate} />
    }

    // 5. Checkout
    if (currentPath === '/checkout') {
      if (!user) {
        navigate('/login')
        return null
      }
      return <Checkout navigate={navigate} />
    }

    // 6. Customer Orders History
    if (currentPath === '/orders') {
      if (!user) {
        navigate('/login')
        return null
      }
      return <Orders navigate={navigate} />
    }

    // 7. Customer Account
    if (currentPath === '/account') {
      if (!user) {
        navigate('/login')
        return null
      }
      return <Account navigate={navigate} />
    }

    // 8. Admin Dashboard
    if (currentPath === '/admin') {
      if (!user || (profile?.role !== 'admin' && profile?.role !== 'developer')) {
        return <AccessDenied navigate={navigate} message="Admin credentials required." />
      }
      return <AdminDashboard navigate={navigate} />
    }

    // 9. Admin Manage Products
    if (currentPath === '/admin/products') {
      if (!user || (profile?.role !== 'admin' && profile?.role !== 'developer')) {
        return <AccessDenied navigate={navigate} message="Admin credentials required." />
      }
      return <AdminProducts navigate={navigate} />
    }

    // 10. Admin Manage Categories
    if (currentPath === '/admin/categories') {
      if (!user || (profile?.role !== 'admin' && profile?.role !== 'developer')) {
        return <AccessDenied navigate={navigate} message="Admin credentials required." />
      }
      return <AdminCategories navigate={navigate} />
    }

    // 11. Admin Manage Orders
    if (currentPath === '/admin/orders') {
      if (!user || (profile?.role !== 'admin' && profile?.role !== 'developer')) {
        return <AccessDenied navigate={navigate} message="Admin credentials required." />
      }
      return <AdminOrders navigate={navigate} />
    }

    // 12. Admin Payment Toggle Configuration
    if (currentPath === '/admin/payments') {
      if (!user || (profile?.role !== 'admin' && profile?.role !== 'developer')) {
        return <AccessDenied navigate={navigate} message="Admin credentials required." />
      }
      return <AdminPayments navigate={navigate} />
    }

    // 13. Developer configuration portal
    if (currentPath === '/developer') {
      if (!user || profile?.role !== 'developer') {
        return <AccessDenied navigate={navigate} message="Developer privileges required." />
      }
      return <DevPortal navigate={navigate} />
    }

    // Default Home page route
    if (currentPath === '/' || currentPath === '') {
      return <Home navigate={navigate} />
    }

    // Fallback 404 page
    return (
      <div className="pt-24 pb-20 text-center px-margin-mobile">
        <span className="material-symbols-outlined text-[64px] text-error">error</span>
        <h2 className="mt-md font-headline font-bold text-headline-lg text-on-surface">Page Not Found</h2>
        <p className="text-on-surface-variant font-label-md mt-xs">The requested URL is not available.</p>
        <button onClick={() => navigate('/')} className="mt-lg bg-primary text-on-primary px-lg py-sm rounded-full font-bold">
          Go to Home
        </button>
      </div>
    )
  }

  // Determine if current route is an administrative or developer route
  const isAdminOrDevRoute = currentPath.startsWith('/admin') || currentPath === '/developer'

  return (
    <div className="min-h-screen flex flex-col justify-between bg-surface text-on-surface">
      {isAdminOrDevRoute ? (
        // Admin layout with distinct header
        <header className="fixed top-0 w-full z-50 bg-inverse-surface h-16 flex justify-between items-center px-margin-mobile md:px-margin-desktop shadow-md text-inverse-on-surface">
          <div className="flex items-center gap-xs">
            <span className="material-symbols-outlined text-primary-container text-2xl" data-icon="shield">shield</span>
            <span className="font-headline font-bold text-headline-md tracking-wide">
              {currentPath === '/developer' ? 'DEVELOPER PORTAL' : 'ADMIN PORTAL'}
            </span>
          </div>
          <div className="flex items-center gap-sm">
            <button 
              onClick={() => navigate('/')}
              className="text-xs bg-primary-container text-on-primary-container px-sm py-1.5 rounded font-bold hover:opacity-90 active:scale-95 transition-all"
            >
              Exit to Storefront
            </button>
          </div>
        </header>
      ) : (
        <Navbar currentPath={currentPath} navigate={navigate} />
      )}

      {/* Main content body */}
      <div className={`${isAdminOrDevRoute ? 'pt-16 pb-12' : ''}`}>
        {renderPage()}
      </div>

      {!isAdminOrDevRoute && <Footer currentPath={currentPath} navigate={navigate} />}
    </div>
  )
}

const AccessDenied = ({ navigate, message }) => (
  <div className="pt-24 pb-20 text-center px-margin-mobile">
    <span className="material-symbols-outlined text-[64px] text-error">gpp_bad</span>
    <h2 className="mt-md font-headline font-bold text-headline-lg text-on-surface">Access Denied</h2>
    <p className="text-on-surface-variant font-label-md mt-xs">{message}</p>
    <div className="mt-lg space-x-sm">
      <button onClick={() => navigate('/login')} className="bg-primary text-on-primary px-lg py-sm rounded-full font-bold active:scale-95">
        Login as Staff
      </button>
      <button onClick={() => navigate('/')} className="bg-surface-container-low border border-outline-variant text-on-surface px-md py-sm rounded-full font-bold active:scale-95">
        Storefront Home
      </button>
    </div>
  </div>
)

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <MainAppLayout />
      </CartProvider>
    </AuthProvider>
  )
}
